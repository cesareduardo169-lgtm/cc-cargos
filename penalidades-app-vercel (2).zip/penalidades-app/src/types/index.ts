/**
 * Tipos del Módulo de Penalidades
 * Fuente de verdad alineada con el schema SQL
 */

// ============================================================
// Enums
// ============================================================

export type PaymentStatus = "PENDIENTE" | "VENCIDO" | "PAGADO";

export type AlertType =
  | "RECORDATORIO_PREVENTIVO"
  | "AVISO_URGENTE"
  | "VENCIMIENTO";

export type AuditAction =
  | "LOGIN"
  | "LOGOUT"
  | "CREATE"
  | "UPDATE"
  | "DELETE"
  | "SOFT_DELETE"
  | "UPLOAD"
  | "DOWNLOAD"
  | "CHANGE_STATUS"
  | "REGISTER_PAYMENT"
  | "CREATE_ND"
  | "SEND_NOTIFICATION"
  | "CHANGE_TARIFF"
  | "VIEW";

export type UserRole = "ADMIN" | "CONTROL_INTERNO" | "FINANZAS" | "CONSULTA";

// ============================================================
// Catálogos
// ============================================================

export interface Provider {
  id: string;
  code: string;
  name: string;
  legal_name?: string | null;
  ruc?: string | null;
  contact_ops_email?: string | null;
  contact_mgmt_email?: string | null;
  contact_finance_email?: string | null;
  phone?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ServiceType {
  id: string;
  code: string;
  name: string;
  description?: string | null;
  is_active: boolean;
}

export interface FailureCategory {
  id: string;
  code: string;
  name: string;
  description?: string | null;
  severity: number;
  is_active: boolean;
}

export interface Location {
  id: string;
  code: string;
  name: string;
  description?: string | null;
  is_active: boolean;
}

export interface Department {
  id: string;
  code: string;
  name: string;
  is_active: boolean;
}

export interface Province {
  id: string;
  department_id: string;
  code: string;
  name: string;
  is_active: boolean;
}

export interface District {
  id: string;
  province_id: string;
  code: string;
  name: string;
  is_active: boolean;
}

// ============================================================
// Tarifas
// ============================================================

export interface Tariff {
  id: string;
  provider_id?: string | null;
  category_id: string;
  location_id: string;
  service_type_id?: string | null;
  cost: number;
  currency: string;
  effective_from: string;
  effective_to?: string | null;
  is_active: boolean;
  notes?: string | null;
  // Joined
  category_name?: string;
  location_name?: string;
  provider_name?: string;
}

export interface TariffLookupResult {
  tariff_id: string;
  cost: number;
}

// ============================================================
// Faltas
// ============================================================

export interface ServiceFailure {
  id: string;
  failure_number: string;
  registered_at: string;
  provider_id: string;
  service_type_id: string;
  category_id: string;
  location_id: string;
  agency?: string | null;
  cod_topaz?: string | null;
  department_id?: string | null;
  province_id?: string | null;
  district_id?: string | null;
  observation?: string | null;
  provider_defense?: string | null;
  penalty_cost: number;
  tariff_id?: string | null;
  defense_file_path?: string | null;
  defense_file_name?: string | null;
  defense_file_mime?: string | null;
  has_debit_note: boolean;
  created_at: string;
  updated_at: string;
  // Joined fields
  provider_name?: string;
  service_type_name?: string;
  category_name?: string;
  location_name?: string;
  department_name?: string;
  province_name?: string;
  district_name?: string;
}

export interface CreateServiceFailureInput {
  provider_id: string;
  service_type_id: string;
  category_id: string;
  location_id: string;
  agency?: string;
  cod_topaz?: string;
  department_id?: string;
  province_id?: string;
  district_id?: string;
  observation?: string;
  provider_defense?: string;
  // penalty_cost y tariff_id se calculan en backend
}

// ============================================================
// Notas de Débito
// ============================================================

export interface DebitNote {
  id: string;
  nd_number: string;
  accounting_date: string;
  external_nd_number?: string | null;
  provider_id: string;
  category_id: string;
  location_id: string;
  failure_id?: string | null;
  delivery_date?: string | null;
  due_date: string;
  amount: number;
  currency: string;
  status: PaymentStatus;
  nd_file_path?: string | null;
  nd_file_name?: string | null;
  nd_file_mime?: string | null;
  xml_file_path?: string | null;
  xml_file_name?: string | null;
  notes?: string | null;
  created_at: string;
  updated_at: string;
  // Joined / computed
  provider_name?: string;
  category_name?: string;
  location_name?: string;
  days_remaining?: number;
  next_alert?: AlertType | null;
}

export interface CreateDebitNoteInput {
  accounting_date: string;
  external_nd_number?: string;
  provider_id: string;
  category_id: string;
  location_id: string;
  failure_id?: string;
  delivery_date?: string;
  amount: number;
  notes?: string;
}

// ============================================================
// Pagos
// ============================================================

export interface Payment {
  id: string;
  debit_note_id: string;
  payment_date: string;
  amount: number;
  currency: string;
  payment_method?: string | null;
  reference?: string | null;
  observation?: string | null;
  support_file_path?: string | null;
  support_file_name?: string | null;
  support_file_mime?: string | null;
  created_at: string;
}

export interface CreatePaymentInput {
  debit_note_id: string;
  payment_date: string;
  amount: number;
  payment_method?: string;
  reference?: string;
  observation?: string;
}

// ============================================================
// Notificaciones
// ============================================================

export interface Notification {
  id: string;
  debit_note_id: string;
  alert_type: AlertType;
  days_remaining: number;
  sent_at?: string | null;
  sent_to?: string[] | null;
  subject?: string | null;
  status: "PENDING" | "SENT" | "FAILED";
  created_at: string;
}

export interface InAppNotification {
  id: string;
  user_id?: string | null;
  role_target?: UserRole | null;
  title: string;
  message: string;
  link?: string | null;
  is_read: boolean;
  related_nd_id?: string | null;
  related_failure_id?: string | null;
  created_at: string;
}

// ============================================================
// Dashboard KPIs
// ============================================================

export interface DashboardKPIs {
  total_failures: number;
  total_penalty_amount: number;
  total_debit_notes: number;
  total_pending: number;
  total_overdue: number;
  total_paid: number;
  pending_amount: number;
  overdue_amount: number;
  paid_amount: number;
}

export interface CategoryDistribution {
  category_name: string;
  count: number;
  amount: number;
}

export interface ProviderDistribution {
  provider_name: string;
  count: number;
  amount: number;
}

export interface MonthlyEvolution {
  month: string;
  failures: number;
  amount: number;
}

export interface UpcomingAlert {
  nd_number: string;
  provider_name: string;
  due_date: string;
  days_remaining: number;
  alert_type: AlertType | null;
  status: PaymentStatus;
}

// ============================================================
// Auditoría
// ============================================================

export interface AuditLog {
  id: string;
  user_id?: string | null;
  user_email?: string | null;
  action: AuditAction;
  table_name?: string | null;
  record_id?: string | null;
  old_data?: Record<string, unknown> | null;
  new_data?: Record<string, unknown> | null;
  ip_address?: string | null;
  created_at: string;
}

// ============================================================
// Configuración
// ============================================================

export interface SystemConfig {
  business_days_payment: number;
  alert_days_preventive: number;
  alert_days_urgent: number;
  alert_days_due: number;
  contractual_threshold: number;
  base_invoice_amount: number;
  company_name: string;
  currency: string;
}

// ============================================================
// Utilidades de respuesta
// ============================================================

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}
