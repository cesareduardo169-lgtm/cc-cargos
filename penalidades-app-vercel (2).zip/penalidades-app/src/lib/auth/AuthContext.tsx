import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  getPermissionsForRole,
  hasPermission,
  type PermissionCode,
  type UserRole,
} from "./permissions";
import type { AuthSession, AuthUser, LoginCredentials } from "./types";

const STORAGE_KEY = "penalidades_auth_session";

/**
 * Usuarios de demostración.
 * En producción se reemplazan por Better Auth / Supabase Auth + tabla profiles.
 * Contraseña demo para todos: demo123
 */
const DEMO_USERS: Array<AuthUser & { password: string }> = [
  {
    id: "u-admin",
    email: "admin@empresa.pe",
    fullName: "Administrador Sistema",
    role: "ADMIN",
    password: "demo123",
  },
  {
    id: "u-control",
    email: "control@empresa.pe",
    fullName: "Ana Control Interno",
    role: "CONTROL_INTERNO",
    password: "demo123",
  },
  {
    id: "u-finanzas",
    email: "finanzas@empresa.pe",
    fullName: "Carlos Finanzas",
    role: "FINANZAS",
    password: "demo123",
  },
  {
    id: "u-consulta",
    email: "consulta@empresa.pe",
    fullName: "María Consulta",
    role: "CONSULTA",
    password: "demo123",
  },
];

interface AuthContextValue {
  session: AuthSession | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: LoginCredentials) => Promise<{ ok: true } | { ok: false; error: string }>;
  logout: () => void;
  /** Atajo: cambiar de rol en modo demo (solo isDemo) */
  switchDemoRole: (role: UserRole) => void;
  can: (permission: PermissionCode) => boolean;
  user: AuthUser | null;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function loadStoredSession(): AuthSession | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AuthSession;
    if (!parsed?.user?.role) return null;
    return {
      ...parsed,
      permissions: getPermissionsForRole(parsed.user.role),
    };
  } catch {
    return null;
  }
}

function persistSession(session: AuthSession | null) {
  if (session) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } else {
    localStorage.removeItem(STORAGE_KEY);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(() =>
    typeof window !== "undefined" ? loadStoredSession() : null
  );
  const [isLoading] = useState(false);

  const login = useCallback(async (credentials: LoginCredentials) => {
    const email = credentials.email.trim().toLowerCase();
    const user = DEMO_USERS.find(
      (u) => u.email === email && u.password === credentials.password
    );

    if (!user) {
      return {
        ok: false as const,
        error: "Correo o contraseña incorrectos. Use las cuentas demo (contraseña: demo123).",
      };
    }

    const { password: _, ...safeUser } = user;
    const next: AuthSession = {
      user: safeUser,
      permissions: getPermissionsForRole(safeUser.role),
      isDemo: true,
    };
    setSession(next);
    persistSession(next);
    return { ok: true as const };
  }, []);

  const logout = useCallback(() => {
    setSession(null);
    persistSession(null);
  }, []);

  const switchDemoRole = useCallback((role: UserRole) => {
    setSession((prev) => {
      if (!prev?.isDemo) return prev;
      const demo = DEMO_USERS.find((u) => u.role === role);
      if (!demo) return prev;
      const { password: _, ...safeUser } = demo;
      const next: AuthSession = {
        user: safeUser,
        permissions: getPermissionsForRole(role),
        isDemo: true,
      };
      persistSession(next);
      return next;
    });
  }, []);

  const can = useCallback(
    (permission: PermissionCode) => {
      if (!session) return false;
      return hasPermission(session.user.role, permission);
    },
    [session]
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      isAuthenticated: !!session,
      isLoading,
      login,
      logout,
      switchDemoRole,
      can,
      user: session?.user ?? null,
    }),
    [session, isLoading, login, logout, switchDemoRole, can]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth debe usarse dentro de AuthProvider");
  }
  return ctx;
}

/** Lista de usuarios demo para la pantalla de login */
export const DEMO_ACCOUNTS = DEMO_USERS.map(({ password, ...u }) => ({
  ...u,
  passwordHint: "demo123",
}));
