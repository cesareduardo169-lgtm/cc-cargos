import type { UserRole, PermissionCode } from "./permissions";

export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
}

export interface AuthSession {
  user: AuthUser;
  permissions: PermissionCode[];
  /** true = sesión de demostración (sin backend) */
  isDemo: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}
