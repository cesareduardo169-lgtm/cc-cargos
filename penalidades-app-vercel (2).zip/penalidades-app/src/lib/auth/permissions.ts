/**
 * Matriz de permisos — espejo del backend (role_permissions).
 * El frontend filtra UI; el backend/DB valida de verdad con user_has_permission().
 */

export type UserRole = "ADMIN" | "CONTROL_INTERNO" | "FINANZAS" | "CONSULTA";

export type PermissionCode =
  | "dashboard.view"
  | "failures.view"
  | "failures.create"
  | "failures.edit"
  | "failures.delete"
  | "failures.adjust_cost"
  | "debit_notes.view"
  | "debit_notes.create"
  | "debit_notes.edit"
  | "payments.view"
  | "payments.register"
  | "alerts.view"
  | "alerts.manage"
  | "catalogs.view"
  | "catalogs.manage"
  | "reports.view"
  | "admin.users"
  | "admin.roles"
  | "admin.audit"
  | "admin.config";

/** Permisos por rol (sin ADMIN: ADMIN tiene todos) */
const ROLE_PERMISSIONS: Record<Exclude<UserRole, "ADMIN">, PermissionCode[]> = {
  CONTROL_INTERNO: [
    "dashboard.view",
    "failures.view",
    "failures.create",
    "failures.edit",
    "debit_notes.view",
    "payments.view",
    "alerts.view",
    "alerts.manage",
    "catalogs.view",
    "reports.view",
  ],
  FINANZAS: [
    "dashboard.view",
    "failures.view",
    "debit_notes.view",
    "debit_notes.create",
    "debit_notes.edit",
    "payments.view",
    "payments.register",
    "alerts.view",
    "catalogs.view",
    "reports.view",
  ],
  CONSULTA: [
    "dashboard.view",
    "failures.view",
    "debit_notes.view",
    "payments.view",
    "alerts.view",
    "catalogs.view",
    "reports.view",
  ],
};

const ALL_PERMISSIONS: PermissionCode[] = [
  "dashboard.view",
  "failures.view",
  "failures.create",
  "failures.edit",
  "failures.delete",
  "failures.adjust_cost",
  "debit_notes.view",
  "debit_notes.create",
  "debit_notes.edit",
  "payments.view",
  "payments.register",
  "alerts.view",
  "alerts.manage",
  "catalogs.view",
  "catalogs.manage",
  "reports.view",
  "admin.users",
  "admin.roles",
  "admin.audit",
  "admin.config",
];

export function getPermissionsForRole(role: UserRole): PermissionCode[] {
  if (role === "ADMIN") return [...ALL_PERMISSIONS];
  return ROLE_PERMISSIONS[role] ?? [];
}

export function hasPermission(role: UserRole, code: PermissionCode): boolean {
  if (role === "ADMIN") return true;
  return getPermissionsForRole(role).includes(code);
}

export function hasAnyPermission(role: UserRole, codes: PermissionCode[]): boolean {
  return codes.some((c) => hasPermission(role, c));
}

/** Etiquetas legibles */
export const ROLE_LABELS: Record<UserRole, string> = {
  ADMIN: "Administrador",
  CONTROL_INTERNO: "Control Interno",
  FINANZAS: "Finanzas",
  CONSULTA: "Consulta",
};

export const ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  ADMIN: "Acceso completo al sistema, usuarios y configuración.",
  CONTROL_INTERNO: "Registro de faltas, alertas y consultas operativas.",
  FINANZAS: "Notas de débito, pagos y seguimiento de cobro.",
  CONSULTA: "Solo lectura de faltas, ND, pagos y reportes.",
};
