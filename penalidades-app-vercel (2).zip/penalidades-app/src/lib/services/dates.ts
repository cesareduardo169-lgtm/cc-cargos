/**
 * Cálculo de días hábiles y fechas de pago
 * Regla de negocio: 30 días hábiles excluyendo sábados y domingos.
 * Preparado para incorporar feriados desde tabla holidays.
 */

/**
 * Suma N días hábiles a una fecha (excluye sábados y domingos).
 * Si se provee lista de feriados, también los excluye.
 */
export function addBusinessDays(
  startDate: Date | string,
  days: number,
  holidays: string[] = [] // ISO date strings YYYY-MM-DD
): Date {
  const holidaySet = new Set(holidays);
  const result = new Date(startDate);
  // Normalizar a medianoche local para evitar problemas de TZ
  result.setHours(0, 0, 0, 0);

  const direction = days >= 0 ? 1 : -1;
  let remaining = Math.abs(days);

  while (remaining > 0) {
    result.setDate(result.getDate() + direction);
    const dayOfWeek = result.getDay(); // 0=Sun, 6=Sat
    const iso = result.toISOString().slice(0, 10);

    if (dayOfWeek !== 0 && dayOfWeek !== 6 && !holidaySet.has(iso)) {
      remaining -= 1;
    }
  }

  return result;
}

/**
 * Calcula la fecha límite de pago = fecha_registro_contable + 30 días hábiles.
 */
export function calculatePaymentDueDate(
  accountingDate: Date | string,
  businessDays: number = 30,
  holidays: string[] = []
): Date {
  return addBusinessDays(accountingDate, businessDays, holidays);
}

/**
 * Calcula días restantes hábiles hasta una fecha.
 * Positivo = faltan días, 0 = hoy, negativo = vencido.
 */
export function businessDaysRemaining(
  dueDate: Date | string,
  fromDate: Date | string = new Date(),
  holidays: string[] = []
): number {
  const due = new Date(dueDate);
  due.setHours(0, 0, 0, 0);
  const from = new Date(fromDate);
  from.setHours(0, 0, 0, 0);

  if (due.getTime() === from.getTime()) return 0;

  const direction = due > from ? 1 : -1;
  let count = 0;
  const current = new Date(from);
  const holidaySet = new Set(holidays);

  while (current.getTime() !== due.getTime()) {
    current.setDate(current.getDate() + direction);
    const dayOfWeek = current.getDay();
    const iso = current.toISOString().slice(0, 10);
    if (dayOfWeek !== 0 && dayOfWeek !== 6 && !holidaySet.has(iso)) {
      count += direction;
    }
  }

  return count;
}

/**
 * Determina el tipo de alerta según días restantes.
 * 10 → RECORDATORIO_PREVENTIVO
 * 5  → AVISO_URGENTE
 * 0  → VENCIMIENTO
 */
export function getAlertTypeForDays(
  daysRemaining: number
): "RECORDATORIO_PREVENTIVO" | "AVISO_URGENTE" | "VENCIMIENTO" | null {
  if (daysRemaining === 10) return "RECORDATORIO_PREVENTIVO";
  if (daysRemaining === 5) return "AVISO_URGENTE";
  if (daysRemaining === 0) return "VENCIMIENTO";
  return null;
}

/**
 * Formatea fecha a YYYY-MM-DD
 */
export function toISODate(date: Date | string): string {
  const d = new Date(date);
  return d.toISOString().slice(0, 10);
}

/**
 * Formatea moneda peruana
 */
export function formatCurrency(amount: number, currency = "PEN"): string {
  return new Intl.NumberFormat("es-PE", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(amount);
}
