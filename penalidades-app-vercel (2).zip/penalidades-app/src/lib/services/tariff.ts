/**
 * Motor de Tarifas — calculatePenalty()
 * Lógica crítica de negocio. Debe ejecutarse en servidor.
 */

import type { TariffLookupResult } from "@/types";

export interface CalculatePenaltyInput {
  provider_id: string;
  category_id: string;
  location_id: string;
  service_type_id?: string | null;
}

export interface CalculatePenaltyResult {
  success: true;
  tariff_id: string;
  cost: number;
} | {
  success: false;
  error: string;
  code: "TARIFF_NOT_FOUND" | "INVALID_INPUT";
};

/**
 * Calcula el costo de penalidad consultando el catálogo de tarifas.
 * Prioridad: tarifa específica de proveedor > genérica.
 * El costo se congela al momento del registro (nunca se recalcula históricamente).
 */
export async function calculatePenalty(
  sql: any, // sql tagged template from getSql()
  input: CalculatePenaltyInput
): Promise<CalculatePenaltyResult> {
  const { provider_id, category_id, location_id, service_type_id } = input;

  if (!provider_id || !category_id || !location_id) {
    return {
      success: false,
      error: "Proveedor, categoría y ubicación son obligatorios para calcular la tarifa.",
      code: "INVALID_INPUT",
    };
  }

  // Consulta alineada con get_current_tariff() del schema
  const rows = await sql`
    SELECT t.id AS tariff_id, t.cost
    FROM tariffs t
    WHERE t.category_id = ${category_id}
      AND t.location_id = ${location_id}
      AND t.is_active = TRUE
      AND (t.effective_to IS NULL OR t.effective_to >= CURRENT_DATE)
      AND t.effective_from <= CURRENT_DATE
      AND (t.provider_id IS NULL OR t.provider_id = ${provider_id})
      AND (
        t.service_type_id IS NULL
        OR t.service_type_id = ${service_type_id ?? null}
      )
    ORDER BY
      CASE WHEN t.provider_id IS NOT NULL THEN 0 ELSE 1 END,
      CASE WHEN t.service_type_id IS NOT NULL THEN 0 ELSE 1 END,
      t.effective_from DESC
    LIMIT 1
  `;

  if (!rows || rows.length === 0) {
    return {
      success: false,
      error:
        "No existe una tarifa configurada para esta combinación de proveedor, categoría y ubicación. Configure primero el catálogo de tarifas.",
      code: "TARIFF_NOT_FOUND",
    };
  }

  return {
    success: true,
    tariff_id: rows[0].tariff_id,
    cost: Number(rows[0].cost),
  };
}

/**
 * Verifica el umbral contractual de 13 faltas.
 * Solo genera alerta, NO incrementa el costo.
 */
export async function checkContractualThreshold(
  sql: any,
  provider_id: string
): Promise<{ count: number; threshold_reached: boolean; threshold: number }> {
  const configRows = await sql`
    SELECT value FROM system_config WHERE key = 'contractual_threshold'
  `;
  const threshold = configRows?.[0] ? Number(configRows[0].value) : 13;

  const countRows = await sql`
    SELECT COUNT(*)::int AS cnt
    FROM service_failures
    WHERE provider_id = ${provider_id}
      AND deleted_at IS NULL
  `;
  const count = countRows?.[0]?.cnt ?? 0;

  return {
    count,
    threshold_reached: count >= threshold,
    threshold,
  };
}
