/**
 * EmailService — Capa independiente de notificaciones
 * Diseñada para conectar posteriormente con Resend, SendGrid, SES o SMTP.
 * No acoplar la aplicación a un único proveedor.
 */

export type EmailProvider = "console" | "resend" | "sendgrid" | "ses" | "smtp";

export interface EmailPayload {
  to: string[];
  cc?: string[];
  subject: string;
  html: string;
  text?: string;
}

export interface EmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

export interface EmailTemplateVars {
  numero_nd: string;
  proveedor: string;
  monto: string;
  fecha_limite: string;
  dias_restantes: number;
  empresa?: string;
}

const TEMPLATES = {
  RECORDATORIO_PREVENTIVO: {
    subject: (v: EmailTemplateVars) =>
      `Recordatorio preventivo — Nota de Débito ${v.numero_nd}`,
    body: (v: EmailTemplateVars) => `
      <p>Estimado equipo de <strong>${v.proveedor}</strong>,</p>
      <p>Le recordamos que la Nota de Débito <strong>${v.numero_nd}</strong>
      por un monto de <strong>${v.monto}</strong> tiene fecha límite de pago
      el <strong>${v.fecha_limite}</strong> (faltan <strong>${v.dias_restantes} días hábiles</strong>).</p>
      <p>Por favor, gestione el pago oportunamente.</p>
      <p>Atentamente,<br/>Control Interno — ${v.empresa ?? "Empresa"}</p>
    `,
  },
  AVISO_URGENTE: {
    subject: (v: EmailTemplateVars) =>
      `Aviso urgente — Nota de Débito ${v.numero_nd}`,
    body: (v: EmailTemplateVars) => `
      <p>Estimado equipo gerencial de <strong>${v.proveedor}</strong>,</p>
      <p><strong>AVISO URGENTE:</strong> La Nota de Débito <strong>${v.numero_nd}</strong>
      por <strong>${v.monto}</strong> vence en <strong>${v.dias_restantes} días hábiles</strong>
      (${v.fecha_limite}).</p>
      <p>Solicitamos su pronta atención para evitar el vencimiento.</p>
      <p>Atentamente,<br/>Control Interno — ${v.empresa ?? "Empresa"}</p>
    `,
  },
  VENCIMIENTO: {
    subject: (v: EmailTemplateVars) =>
      `Vencimiento de pago — Nota de Débito ${v.numero_nd}`,
    body: (v: EmailTemplateVars) => `
      <p>Estimados,</p>
      <p>La Nota de Débito <strong>${v.numero_nd}</strong> de <strong>${v.proveedor}</strong>
      por <strong>${v.monto}</strong> <strong>vence el día de hoy</strong> (${v.fecha_limite}).</p>
      <p>Se requiere gestión inmediata de cobro / pago.</p>
      <p>Copias: Finanzas · Tesorería</p>
      <p>Atentamente,<br/>${v.empresa ?? "Empresa"}</p>
    `,
  },
} as const;

export type AlertTemplateKey = keyof typeof TEMPLATES;

/**
 * Renderiza plantilla de alerta.
 */
export function renderAlertEmail(
  type: AlertTemplateKey,
  vars: EmailTemplateVars
): { subject: string; html: string } {
  const tpl = TEMPLATES[type];
  return {
    subject: tpl.subject(vars),
    html: tpl.body(vars),
  };
}

/**
 * EmailService abstracto.
 * Implementación actual: console (desarrollo).
 * En producción se inyecta el proveedor real.
 */
export class EmailService {
  constructor(private provider: EmailProvider = "console") {}

  async send(payload: EmailPayload): Promise<EmailResult> {
    switch (this.provider) {
      case "console":
        console.log("[EmailService:console]", {
          to: payload.to,
          subject: payload.subject,
          htmlPreview: payload.html.slice(0, 120) + "...",
        });
        return { success: true, messageId: `console-${Date.now()}` };

      // Placeholders para proveedores reales
      case "resend":
      case "sendgrid":
      case "ses":
      case "smtp":
        // TODO: implementar con las variables de entorno correspondientes
        console.warn(`[EmailService] Proveedor ${this.provider} no configurado aún.`);
        return {
          success: false,
          error: `Proveedor de email "${this.provider}" no implementado. Configure EMAIL_PROVIDER y las claves necesarias.`,
        };

      default:
        return { success: false, error: "Proveedor de email desconocido" };
    }
  }

  /**
   * Envía alerta de ND usando plantilla.
   */
  async sendAlert(
    type: AlertTemplateKey,
    to: string[],
    vars: EmailTemplateVars
  ): Promise<EmailResult> {
    const { subject, html } = renderAlertEmail(type, vars);
    return this.send({ to, subject, html });
  }
}

/** Instancia por defecto (console en desarrollo) */
export const emailService = new EmailService(
  (process.env.EMAIL_PROVIDER as EmailProvider) || "console"
);
