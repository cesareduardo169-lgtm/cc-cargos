/**
 * Esquemas de validación Zod — reglas de negocio y formularios
 */

import { z } from "zod";

// ============================================================
// Catálogos
// ============================================================

export const providerSchema = z.object({
  code: z.string().min(1).max(50),
  name: z.string().min(1).max(150),
  legal_name: z.string().max(200).optional().nullable(),
  ruc: z.string().max(20).optional().nullable(),
  contact_ops_email: z.string().email().optional().nullable().or(z.literal("")),
  contact_mgmt_email: z.string().email().optional().nullable().or(z.literal("")),
  contact_finance_email: z.string().email().optional().nullable().or(z.literal("")),
  phone: z.string().max(30).optional().nullable(),
  is_active: z.boolean().default(true),
});

// ============================================================
// Registro de Falta
// ============================================================

export const createFailureSchema = z.object({
  provider_id: z.string().uuid("Seleccione un proveedor válido"),
  service_type_id: z.string().uuid("Seleccione un tipo de servicio válido"),
  category_id: z.string().uuid("Seleccione una categoría de falta válida"),
  location_id: z.string().uuid("Seleccione una ubicación válida"),
  agency: z.string().max(150).optional().nullable(),
  cod_topaz: z.string().max(50).optional().nullable(),
  department_id: z.string().uuid().optional().nullable(),
  province_id: z.string().uuid().optional().nullable(),
  district_id: z.string().uuid().optional().nullable(),
  observation: z.string().max(5000).optional().nullable(),
  provider_defense: z.string().max(5000).optional().nullable(),
});

export type CreateFailureForm = z.infer<typeof createFailureSchema>;

// ============================================================
// Nota de Débito
// ============================================================

export const createDebitNoteSchema = z.object({
  accounting_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Fecha inválida"),
  external_nd_number: z.string().max(50).optional().nullable(),
  provider_id: z.string().uuid("Seleccione un proveedor válido"),
  category_id: z.string().uuid("Seleccione una categoría válida"),
  location_id: z.string().uuid("Seleccione una ubicación válida"),
  failure_id: z.string().uuid().optional().nullable(),
  delivery_date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional()
    .nullable(),
  amount: z.number().positive("El monto debe ser mayor a cero"),
  notes: z.string().max(2000).optional().nullable(),
});

export type CreateDebitNoteForm = z.infer<typeof createDebitNoteSchema>;

// ============================================================
// Pago
// ============================================================

export const createPaymentSchema = z.object({
  debit_note_id: z.string().uuid(),
  payment_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Fecha inválida"),
  amount: z.number().positive("El monto debe ser mayor a cero"),
  payment_method: z.string().max(50).optional().nullable(),
  reference: z.string().max(100).optional().nullable(),
  observation: z.string().max(1000).optional().nullable(),
});

export type CreatePaymentForm = z.infer<typeof createPaymentSchema>;

// ============================================================
// Filtros de listados
// ============================================================

export const listFiltersSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(5).max(100).default(20),
  search: z.string().max(100).optional(),
  provider_id: z.string().uuid().optional(),
  category_id: z.string().uuid().optional(),
  location_id: z.string().uuid().optional(),
  status: z.enum(["PENDIENTE", "VENCIDO", "PAGADO"]).optional(),
  date_from: z.string().optional(),
  date_to: z.string().optional(),
  sort_by: z.string().optional(),
  sort_dir: z.enum(["asc", "desc"]).default("desc"),
});
