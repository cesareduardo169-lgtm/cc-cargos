import { useState } from "react";
import { Shield, LogIn, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth, DEMO_ACCOUNTS } from "@/lib/auth/AuthContext";
import { ROLE_LABELS } from "@/lib/auth/permissions";

export function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result = await login({ email, password });
    setLoading(false);
    if (!result.ok) {
      setError(result.error);
    }
  };

  const fillDemo = (demoEmail: string) => {
    setEmail(demoEmail);
    setPassword("demo123");
    setError(null);
  };

  return (
    <div className="flex min-h-screen">
      {/* Panel izquierdo — branding */}
      <div className="hidden lg:flex lg:w-[42%] flex-col justify-between bg-[var(--color-sidebar)] p-10 text-[var(--color-fg-on-dark)]">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-primary)]">
            <Shield className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="font-semibold leading-tight">Módulo de Penalidades</p>
            <p className="text-xs text-[var(--color-fg-on-dark-muted)]">
              Gestión contractual
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <h1 className="text-3xl font-semibold tracking-tight text-balance leading-snug">
            Control integral de penalidades a proveedores de seguridad
          </h1>
          <p className="text-sm text-[var(--color-fg-on-dark-muted)] max-w-md leading-relaxed">
            Registro de faltas, formalización de notas de débito, seguimiento de
            cobro y alertas automatizadas — con roles y auditoría.
          </p>
        </div>

        <p className="text-[11px] text-[var(--color-fg-on-dark-muted)]">
          Acceso restringido · Roles: Admin · Control Interno · Finanzas · Consulta
        </p>
      </div>

      {/* Panel derecho — formulario */}
      <div className="flex flex-1 flex-col items-center justify-center p-6 sm:p-10 bg-[var(--color-bg)]">
        <div className="w-full max-w-[400px] space-y-6">
          <div className="lg:hidden flex items-center gap-2.5 mb-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-primary)]">
              <Shield className="h-4 w-4 text-white" />
            </div>
            <span className="font-semibold text-[var(--color-fg)]">Penalidades</span>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-[var(--color-fg)]">Iniciar sesión</h2>
            <p className="mt-1 text-sm text-[var(--color-fg-muted)]">
              Ingrese con su cuenta corporativa
            </p>
          </div>

          <Card>
            <CardContent className="pt-5">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email" required>
                    Correo electrónico
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    autoComplete="username"
                    placeholder="usuario@empresa.pe"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="password" required>
                    Contraseña
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      autoComplete="current-password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="pr-10"
                    />
                    <button
                      type="button"
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-[var(--color-fg-subtle)] hover:text-[var(--color-fg)]"
                      onClick={() => setShowPassword((v) => !v)}
                      tabIndex={-1}
                      aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                {error && (
                  <div
                    className="rounded-[var(--radius-md)] border border-[var(--color-danger)]/30 bg-[var(--color-danger-bg)] px-3 py-2 text-sm text-[var(--color-danger)]"
                    role="alert"
                  >
                    {error}
                  </div>
                )}

                <Button type="submit" className="w-full" disabled={loading}>
                  <LogIn className="h-4 w-4" />
                  {loading ? "Ingresando..." : "Ingresar"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Cuentas demo */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Cuentas de demostración</CardTitle>
              <CardDescription className="text-xs">
                Contraseña para todas: <code className="font-mono text-[var(--color-fg)]">demo123</code>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-1.5 pt-0">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.id}
                  type="button"
                  onClick={() => fillDemo(acc.email)}
                  className="flex w-full items-center justify-between rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-bg)] px-3 py-2 text-left text-sm hover:bg-[var(--color-bg-subtle)] transition-colors"
                >
                  <div className="min-w-0">
                    <p className="font-medium truncate">{acc.fullName}</p>
                    <p className="text-xs text-[var(--color-fg-muted)] truncate">{acc.email}</p>
                  </div>
                  <Badge variant="outline" className="shrink-0 ml-2">
                    {ROLE_LABELS[acc.role]}
                  </Badge>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
