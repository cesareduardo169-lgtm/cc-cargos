import { DataTable, StatusBadge, type Column } from "@/components/tables/DataTable";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type NDRow = {
  id: string;
  accounting_date: string;
  delivery_date: string;
  nd_number: string;
  provider_name: string;
  due_date: string;
  days_remaining: number;
  status: string;
  next_alert: string | null;
  amount: number;
};

const DEMO: NDRow[] = [
  {
    id: "1",
    accounting_date: "2026-08-15",
    delivery_date: "2026-08-16",
    nd_number: "ND-2026-0007",
    provider_name: "SECURITY SALES",
    due_date: "2026-09-20",
    days_remaining: 0,
    status: "PENDIENTE",
    next_alert: "VENCIMIENTO",
    amount: 5245,
  },
  {
    id: "2",
    accounting_date: "2026-08-18",
    delivery_date: "2026-08-19",
    nd_number: "ND-2026-0009",
    provider_name: "PROSEGURIDAD",
    due_date: "2026-09-25",
    days_remaining: 5,
    status: "PENDIENTE",
    next_alert: "URGENTE",
    amount: 5245,
  },
  {
    id: "3",
    accounting_date: "2026-08-20",
    delivery_date: "2026-08-21",
    nd_number: "ND-2026-0011",
    provider_name: "G4S",
    due_date: "2026-09-18",
    days_remaining: -2,
    status: "VENCIDO",
    next_alert: null,
    amount: 367,
  },
  {
    id: "4",
    accounting_date: "2026-08-22",
    delivery_date: "2026-08-23",
    nd_number: "ND-2026-0012",
    provider_name: "G4S",
    due_date: "2026-09-22",
    days_remaining: 2,
    status: "PENDIENTE",
    next_alert: "URGENTE",
    amount: 5245,
  },
  {
    id: "5",
    accounting_date: "2026-07-10",
    delivery_date: "2026-07-11",
    nd_number: "ND-2026-0003",
    provider_name: "COMETAL",
    due_date: "2026-08-21",
    days_remaining: -30,
    status: "PAGADO",
    next_alert: null,
    amount: 400,
  },
  {
    id: "6",
    accounting_date: "2026-08-28",
    delivery_date: "2026-08-29",
    nd_number: "ND-2026-0015",
    provider_name: "COMETAL",
    due_date: "2026-09-30",
    days_remaining: 10,
    status: "PENDIENTE",
    next_alert: "PREVENTIVA",
    amount: 5245,
  },
];

const alertVariant = (a: string | null) => {
  if (a === "PREVENTIVA") return "info" as const;
  if (a === "URGENTE") return "warning" as const;
  if (a === "VENCIMIENTO") return "danger" as const;
  return "default" as const;
};

const columns: Column<NDRow>[] = [
  {
    key: "accounting_date",
    header: "Fecha registro",
    render: (r) => <span className="tabular-nums text-[var(--color-fg-muted)]">{r.accounting_date}</span>,
  },
  {
    key: "delivery_date",
    header: "Fecha entrega",
    render: (r) => <span className="tabular-nums text-[var(--color-fg-muted)]">{r.delivery_date}</span>,
  },
  {
    key: "nd_number",
    header: "Nº ND",
    render: (r) => (
      <span className="font-medium tabular-nums text-[var(--color-primary)]">{r.nd_number}</span>
    ),
  },
  { key: "provider_name", header: "Proveedor" },
  {
    key: "due_date",
    header: "Fecha límite",
    render: (r) => <span className="tabular-nums">{r.due_date}</span>,
  },
  {
    key: "days_remaining",
    header: "Días rest.",
    render: (r) => {
      const n = r.days_remaining;
      const color =
        n < 0
          ? "text-[var(--color-danger)]"
          : n <= 5
          ? "text-[var(--color-warning)]"
          : "text-[var(--color-fg)]";
      return (
        <span className={`font-medium tabular-nums ${color}`}>
          {n < 0 ? `${n}d` : n === 0 ? "Hoy" : `${n}d`}
        </span>
      );
    },
  },
  {
    key: "status",
    header: "Estado",
    render: (r) => <StatusBadge status={r.status} />,
  },
  {
    key: "next_alert",
    header: "Próxima alerta",
    render: (r) =>
      r.next_alert ? (
        <Badge variant={alertVariant(r.next_alert)}>{r.next_alert}</Badge>
      ) : (
        <span className="text-[var(--color-fg-subtle)]">—</span>
      ),
  },
  {
    key: "amount",
    header: "Monto",
    render: (r) => (
      <span className="font-medium tabular-nums">
        S/ {r.amount.toLocaleString("es-PE", { minimumFractionDigits: 2 })}
      </span>
    ),
  },
];

export function PaymentTrackingPage() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Seguimiento de Pagos</h2>
          <p className="text-sm text-[var(--color-fg-muted)]">
            Control de notas de débito, plazos y alertas
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            Solo vencidos
          </Button>
          <Button variant="outline" size="sm">
            Solo pendientes
          </Button>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={DEMO}
        searchPlaceholder="Buscar por ND, proveedor..."
      />
    </div>
  );
}
