import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ROLE_LABELS,
  ROLE_DESCRIPTIONS,
  getPermissionsForRole,
  type UserRole,
  type PermissionCode,
} from "@/lib/auth/permissions";

const ROLES: UserRole[] = ["ADMIN", "CONTROL_INTERNO", "FINANZAS", "CONSULTA"];

const PERMISSION_LABELS: Record<PermissionCode, string> = {
  "dashboard.view": "Ver dashboard",
  "failures.view": "Ver faltas",
  "failures.create": "Registrar faltas",
  "failures.edit": "Editar faltas",
  "failures.delete": "Eliminar faltas",
  "failures.adjust_cost": "Ajustar costo manual",
  "debit_notes.view": "Ver ND",
  "debit_notes.create": "Registrar ND",
  "debit_notes.edit": "Editar ND",
  "payments.view": "Ver pagos",
  "payments.register": "Registrar pago",
  "alerts.view": "Ver alertas",
  "alerts.manage": "Gestionar alertas",
  "catalogs.view": "Ver catálogos",
  "catalogs.manage": "Administrar catálogos",
  "reports.view": "Ver reportes",
  "admin.users": "Gestionar usuarios",
  "admin.roles": "Gestionar roles",
  "admin.audit": "Ver auditoría",
  "admin.config": "Configuración sistema",
};

const MODULES = [
  { key: "dashboard", label: "Dashboard" },
  { key: "failures", label: "Faltas" },
  { key: "debit_notes", label: "Notas de Débito" },
  { key: "payments", label: "Pagos" },
  { key: "alerts", label: "Alertas" },
  { key: "catalogs", label: "Catálogos" },
  { key: "reports", label: "Reportes" },
  { key: "admin", label: "Administración" },
] as const;

export function RolesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold">Roles y permisos</h2>
        <p className="text-sm text-[var(--color-fg-muted)]">
          Matriz de acceso del sistema. Los permisos se validan también en backend.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {ROLES.map((role) => (
          <Card key={role}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-base">{ROLE_LABELS[role]}</CardTitle>
                <Badge variant={role === "ADMIN" ? "primary" : "outline"}>{role}</Badge>
              </div>
              <CardDescription className="text-xs leading-relaxed">
                {ROLE_DESCRIPTIONS[role]}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-[11px] text-[var(--color-fg-subtle)]">
                {getPermissionsForRole(role).length} permisos
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Matriz de permisos</CardTitle>
          <CardDescription>
            ✓ = permitido · vacío = denegado (ADMIN tiene todos)
          </CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto pt-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[var(--color-border)]">
                <th className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-[var(--color-fg-muted)]">
                  Permiso
                </th>
                {ROLES.map((r) => (
                  <th
                    key={r}
                    className="px-3 py-2 text-center text-xs font-semibold uppercase tracking-wider text-[var(--color-fg-muted)]"
                  >
                    {ROLE_LABELS[r].split(" ")[0]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MODULES.map((mod) => {
                const perms = (
                  Object.keys(PERMISSION_LABELS) as PermissionCode[]
                ).filter((p) => p.startsWith(mod.key + "."));
                return (
                  <>
                    <tr key={mod.key} className="bg-[var(--color-bg-subtle)]">
                      <td
                        colSpan={5}
                        className="px-3 py-1.5 text-xs font-semibold text-[var(--color-fg-muted)]"
                      >
                        {mod.label}
                      </td>
                    </tr>
                    {perms.map((code) => (
                      <tr
                        key={code}
                        className="border-b border-[var(--color-border)] last:border-0"
                      >
                        <td className="px-3 py-2 text-[var(--color-fg)]">
                          {PERMISSION_LABELS[code]}
                          <span className="ml-2 font-mono text-[10px] text-[var(--color-fg-subtle)]">
                            {code}
                          </span>
                        </td>
                        {ROLES.map((role) => {
                          const ok =
                            role === "ADMIN" ||
                            getPermissionsForRole(role).includes(code);
                          return (
                            <td key={role} className="px-3 py-2 text-center">
                              {ok ? (
                                <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-success-bg)] text-[var(--color-success)] text-xs font-bold">
                                  ✓
                                </span>
                              ) : (
                                <span className="text-[var(--color-fg-subtle)]">—</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </>
                );
              })}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
