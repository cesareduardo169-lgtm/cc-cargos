import { KPICards } from "@/components/dashboard/KPICards";
import { CategoryChart, ProviderChart, StatusChart } from "@/components/dashboard/Charts";
import { UpcomingAlerts } from "@/components/dashboard/UpcomingAlerts";

export function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-[var(--color-fg)]">
          Panel de control
        </h2>
        <p className="text-sm text-[var(--color-fg-muted)]">
          Resumen en tiempo real del módulo de penalidades
        </p>
      </div>

      <KPICards />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <CategoryChart />
        </div>
        <StatusChart />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ProviderChart />
        <UpcomingAlerts />
      </div>
    </div>
  );
}
