import { useMemo, useState } from "react";
import { ArrowLeft, Calculator, AlertTriangle, Save, Info, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Textarea, Label } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  getAgencies,
  findAgencyById,
  PROVIDER_CONTRACT_INFO,
  DEMO_ACCUMULATED_FAULTS,
  type Agency,
} from "@/lib/data/agencies";

const PROVIDERS = ["G4S", "PROSEGURIDAD", "COMETAL", "SECURITY SALES"];
const SERVICE_TYPES = ["Servicio Fijo", "Servicio Especial", "Proyecto de Llaves"];
const CATEGORIES = [
  "Falta Grave",
  "Faltas en el Servicio",
  "Faltas Regulatorias",
  "Personal no Idóneo",
  "Tardanzas",
];
const LOCATIONS = ["Red de Agencia", "Sede Principal"];

function calcCost(category: string, location: string): number | null {
  if (!category || !location) return null;
  if (category === "Falta Grave") return 367;
  if (category === "Personal no Idóneo" && location === "Sede Principal") return 400;
  if (
    [
      "Faltas en el Servicio",
      "Faltas Regulatorias",
      "Tardanzas",
      "Personal no Idóneo",
    ].includes(category)
  ) {
    return 5245;
  }
  return null;
}

const PCT_CATEGORIES = [
  "Faltas en el Servicio",
  "Faltas Regulatorias",
  "Tardanzas",
  "Personal no Idóneo",
];

interface NewFailurePageProps {
  onBack?: () => void;
}

export function NewFailurePage({ onBack }: NewFailurePageProps) {
  const [provider, setProvider] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [agencySearch, setAgencySearch] = useState("");
  const [agencyId, setAgencyId] = useState("");
  const [codTopaz, setCodTopaz] = useState("");
  const [department, setDepartment] = useState("");
  const [province, setProvince] = useState("");
  const [district, setDistrict] = useState("");
  const [address, setAddress] = useState("");
  const [saved, setSaved] = useState(false);

  const agencies = useMemo(() => {
    if (!location) return [];
    return getAgencies(location, agencySearch);
  }, [location, agencySearch]);

  const selectedAgency: Agency | undefined = agencyId
    ? findAgencyById(agencyId)
    : undefined;

  const cost = calcCost(category, location);
  const contractInfo = provider ? PROVIDER_CONTRACT_INFO[provider] : null;
  const accumulated = provider ? DEMO_ACCUMULATED_FAULTS[provider] ?? 0 : 0;
  const threshold = contractInfo?.faultThreshold ?? 13;
  const afterSaveCount = accumulated + 1;
  const thresholdReached = afterSaveCount >= threshold;
  const nearThreshold = accumulated >= threshold - 2 && !thresholdReached;

  const selectClass =
    "flex h-9 w-full rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-bg-elevated)] px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] disabled:opacity-50";

  const onLocationChange = (value: string) => {
    setLocation(value);
    setAgencyId("");
    setAgencySearch("");
    setCodTopaz("");
    setDepartment("");
    setProvince("");
    setDistrict("");
    setAddress("");
  };

  const onAgencyChange = (id: string) => {
    setAgencyId(id);
    const ag = findAgencyById(id);
    if (ag) {
      setCodTopaz(ag.cod_topaz);
      setDepartment(ag.department);
      setProvince(ag.province);
      setDistrict(ag.district);
      setAddress(ag.address);
    } else {
      setCodTopaz("");
      setDepartment("");
      setProvince("");
      setDistrict("");
      setAddress("");
    }
  };

  if (saved) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-success-bg)]">
          <Save className="h-6 w-6 text-[var(--color-success)]" />
        </div>
        <h2 className="text-xl font-semibold">Falta registrada correctamente</h2>
        <p className="text-[var(--color-fg-muted)]">
          Se generó el correlativo{" "}
          <span className="font-semibold text-[var(--color-primary)] tabular-nums">
            FLT-2026-0007
          </span>
        </p>
        {selectedAgency && (
          <p className="text-sm text-[var(--color-fg-muted)]">
            {selectedAgency.name} · {selectedAgency.department} · Topaz{" "}
            <span className="font-mono">{selectedAgency.cod_topaz}</span>
          </p>
        )}
        {thresholdReached && (
          <div className="rounded-[var(--radius-lg)] border border-[var(--color-warning)] bg-[var(--color-warning-bg)] px-4 py-3 text-left text-sm">
            <p className="font-medium text-[var(--color-warning)]">Alerta contractual</p>
            <p className="text-[var(--color-fg-muted)] text-xs mt-1">
              El proveedor {provider} alcanzó o superó el umbral de {threshold} faltas
              acumuladas. Se requiere revisión contractual. El costo unitario no se
              incrementa.
            </p>
          </div>
        )}
        <div className="flex justify-center gap-2 pt-2">
          <Button variant="outline" onClick={onBack}>
            Volver al listado
          </Button>
          <Button
            onClick={() => {
              setSaved(false);
              setAgencyId("");
              setCodTopaz("");
              setCategory("");
              setAgencySearch("");
            }}
          >
            Registrar otra
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-lg font-semibold">Nueva Falta</h2>
          <p className="text-sm text-[var(--color-fg-muted)]">
            Registro de incidencia · Agencias MiBanco (KIGAN SSP)
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Identificación</CardTitle>
          <CardDescription>
            Número correlativo: <Badge variant="outline">FLT-2026-XXXX</Badge> (automático)
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label required>Proveedor de seguridad</Label>
            <select
              className={selectClass}
              value={provider}
              onChange={(e) => setProvider(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {PROVIDERS.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label required>Tipo de Servicio</Label>
            <select
              className={selectClass}
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {SERVICE_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label required>Categoría de Falta</Label>
            <select
              className={selectClass}
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label required>Ubicación</Label>
            <select
              className={selectClass}
              value={location}
              onChange={(e) => onLocationChange(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {LOCATIONS.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {contractInfo && (
        <div className="flex items-start gap-3 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-bg-elevated)] px-4 py-3">
          <Info className="h-4 w-4 shrink-0 mt-0.5 text-[var(--color-info)]" />
          <div className="text-xs text-[var(--color-fg-muted)] space-y-1">
            <p className="font-medium text-[var(--color-fg)]">
              {provider} · contexto contractual
            </p>
            <p>{contractInfo.notes}</p>
            <p>
              Faltas acumuladas (demo):{" "}
              <strong className="tabular-nums">{accumulated}</strong> / {threshold}
            </p>
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>
            {location === "Sede Principal" ? "Sede Principal" : "Agencia MiBanco"}
          </CardTitle>
          <CardDescription>
            Listado oficial KIGAN SSP (
            {location === "Red de Agencia" ? "250 agencias" : "Sede"}). Al seleccionar se
            completan Topaz, ubigeo y dirección.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          {location === "Red de Agencia" && (
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Buscar agencia</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-fg-subtle)]" />
                <Input
                  className="pl-8"
                  placeholder="Nombre, distrito, departamento, código Topaz..."
                  value={agencySearch}
                  onChange={(e) => setAgencySearch(e.target.value)}
                  disabled={!location}
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5 sm:col-span-2">
            <Label required>
              {location === "Sede Principal" ? "Sede" : "Agencia"}
            </Label>
            <select
              className={selectClass}
              value={agencyId}
              onChange={(e) => onAgencyChange(e.target.value)}
              disabled={!location}
              size={location === "Red de Agencia" && agencies.length > 8 ? 8 : undefined}
              style={
                location === "Red de Agencia" && agencies.length > 8
                  ? { height: "auto", minHeight: "9rem" }
                  : undefined
              }
            >
              <option value="">
                {!location
                  ? "Seleccione primero la ubicación"
                  : agencies.length === 0
                  ? "Sin resultados para la búsqueda"
                  : "Seleccionar..."}
              </option>
              {agencies.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                  {a.location === "Red de Agencia"
                    ? ` — ${a.district}, ${a.department} (${a.cod_topaz})`
                    : ` (${a.cod_topaz})`}
                </option>
              ))}
            </select>
            {location === "Red de Agencia" && (
              <p className="text-[11px] text-[var(--color-fg-subtle)]">
                Mostrando {agencies.length} agencia(s)
                {agencySearch ? ` filtradas por "${agencySearch}"` : " (todas)"}
              </p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>Código Topaz</Label>
            <Input
              value={codTopaz}
              onChange={(e) => setCodTopaz(e.target.value)}
              placeholder="Se completa al elegir agencia"
              className="font-mono"
              readOnly={!!selectedAgency}
            />
            <p className="text-[11px] text-[var(--color-fg-subtle)]">
              Provisional MB-NNNN hasta cargar códigos Topaz oficiales
            </p>
          </div>

          <div className="space-y-1.5">
            <Label>Código agencia</Label>
            <Input
              value={selectedAgency?.code ?? ""}
              readOnly
              placeholder="—"
              className="font-mono bg-[var(--color-bg-subtle)]"
            />
          </div>

          <div className="space-y-1.5">
            <Label>Departamento</Label>
            <Input value={department} readOnly className="bg-[var(--color-bg-subtle)]" />
          </div>
          <div className="space-y-1.5">
            <Label>Provincia</Label>
            <Input value={province} readOnly className="bg-[var(--color-bg-subtle)]" />
          </div>
          <div className="space-y-1.5">
            <Label>Distrito</Label>
            <Input value={district} readOnly className="bg-[var(--color-bg-subtle)]" />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Dirección</Label>
            <Input value={address} readOnly className="bg-[var(--color-bg-subtle)]" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detalle del incumplimiento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label required>Observación</Label>
            <Textarea placeholder="Describa el incumplimiento detectado..." rows={3} />
          </div>
          <div className="space-y-1.5">
            <Label>Descargo del proveedor</Label>
            <Textarea placeholder="Justificación o descargo (opcional)..." rows={2} />
          </div>
          <div className="space-y-1.5">
            <Label>Adjuntar descargo</Label>
            <Input type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" />
            <p className="text-[11px] text-[var(--color-fg-subtle)]">
              PDF, JPG, PNG, DOC/DOCX · máx. 10 MB
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-[var(--color-primary)]/30 bg-[var(--color-primary-muted)]/30">
        <CardContent className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-primary)] text-white">
              <Calculator className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium">Costo de Penalidad</p>
              <p className="text-xs text-[var(--color-fg-muted)]">
                {category &&
                PCT_CATEGORIES.includes(category) &&
                !(category === "Personal no Idóneo" && location === "Sede Principal")
                  ? "1% factura base sin IGV → S/ 5,245"
                  : category === "Personal no Idóneo" && location === "Sede Principal"
                  ? "Excepción fija Sede Principal"
                  : category === "Falta Grave"
                  ? "Costo fijo contractual"
                  : "Según catálogo de tarifas"}
              </p>
            </div>
          </div>
          <div className="text-right">
            {cost !== null ? (
              <p className="text-2xl font-semibold tabular-nums text-[var(--color-primary)]">
                S/ {cost.toLocaleString("es-PE", { minimumFractionDigits: 2 })}
              </p>
            ) : (
              <p className="text-sm text-[var(--color-fg-muted)]">
                Seleccione categoría y ubicación
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {nearThreshold && (
        <div className="flex items-start gap-3 rounded-[var(--radius-lg)] border border-[var(--color-warning)]/50 bg-[var(--color-warning-bg)] p-4">
          <AlertTriangle className="h-5 w-5 shrink-0 text-[var(--color-warning)]" />
          <div>
            <p className="text-sm font-medium text-[var(--color-warning)]">
              Cerca del umbral contractual
            </p>
            <p className="text-xs text-[var(--color-fg-muted)]">
              {provider} tiene {accumulated} faltas (umbral {threshold}). Al registrar
              quedará en {afterSaveCount}. El costo unitario no cambia.
            </p>
          </div>
        </div>
      )}

      {thresholdReached && (
        <div className="flex items-start gap-3 rounded-[var(--radius-lg)] border border-[var(--color-warning)] bg-[var(--color-warning-bg)] p-4">
          <AlertTriangle className="h-5 w-5 shrink-0 text-[var(--color-warning)]" />
          <div>
            <p className="text-sm font-medium text-[var(--color-warning)]">
              Alerta contractual
            </p>
            <p className="text-xs text-[var(--color-fg-muted)]">
              {provider} alcanzará el umbral de {threshold} faltas acumuladas. Se requiere
              revisión contractual. <strong>El costo de cada falta no se incrementa.</strong>
            </p>
          </div>
        </div>
      )}

      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onBack}>
          Cancelar
        </Button>
        <Button
          onClick={() => setSaved(true)}
          disabled={
            !provider ||
            !serviceType ||
            !category ||
            !location ||
            !agencyId ||
            cost === null
          }
        >
          <Save className="h-4 w-4" />
          Guardar Falta
        </Button>
      </div>
    </div>
  );
}
