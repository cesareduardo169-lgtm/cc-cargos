import { useState, useEffect } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { DashboardPage } from "@/pages/DashboardPage";
import { FailuresListPage } from "@/pages/FailuresListPage";
import { NewFailurePage } from "@/pages/NewFailurePage";
import { PaymentTrackingPage } from "@/pages/PaymentTrackingPage";
import { LoginPage } from "@/pages/LoginPage";
import { RolesPage } from "@/pages/RolesPage";
import { AuthProvider, useAuth } from "@/lib/auth/AuthContext";
import type { PermissionCode } from "@/lib/auth/permissions";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

const TITLES: Record<string, string> = {
  "/": "Dashboard",
  "/penalidades": "Listado de Faltas",
  "/penalidades/nueva": "Registrar Falta",
  "/penalidades/historial": "Historial de Faltas",
  "/notas-debito": "Listado de ND",
  "/notas-debito/nueva": "Registrar ND",
  "/notas-debito/seguimiento": "Seguimiento de Pagos",
  "/catalogos/proveedores": "Proveedores",
  "/catalogos/tipos-servicio": "Tipos de Servicio",
  "/catalogos/categorias": "Categorías de Falta",
  "/catalogos/ubicaciones": "Ubicaciones",
  "/catalogos/tarifas": "Tarifas",
  "/catalogos/geografia": "Geografía",
  "/alertas/proximas": "Alertas próximas",
  "/alertas/vencidas": "Alertas vencidas",
  "/alertas/historial": "Historial de alertas",
  "/reportes": "Reportes",
  "/admin/usuarios": "Usuarios",
  "/admin/roles": "Roles",
  "/admin/permisos": "Permisos",
  "/admin/auditoria": "Auditoría",
};

/** Ruta → permiso requerido (si no está, solo requiere estar autenticado) */
const ROUTE_PERMISSIONS: Record<string, PermissionCode> = {
  "/": "dashboard.view",
  "/penalidades": "failures.view",
  "/penalidades/nueva": "failures.create",
  "/penalidades/historial": "failures.view",
  "/notas-debito": "debit_notes.view",
  "/notas-debito/nueva": "debit_notes.create",
  "/notas-debito/seguimiento": "payments.view",
  "/catalogos/proveedores": "catalogs.view",
  "/catalogos/tipos-servicio": "catalogs.view",
  "/catalogos/categorias": "catalogs.view",
  "/catalogos/ubicaciones": "catalogs.view",
  "/catalogos/tarifas": "catalogs.view",
  "/catalogos/geografia": "catalogs.view",
  "/alertas/proximas": "alerts.view",
  "/alertas/vencidas": "alerts.view",
  "/alertas/historial": "alerts.view",
  "/reportes": "reports.view",
  "/admin/usuarios": "admin.users",
  "/admin/roles": "admin.roles",
  "/admin/permisos": "admin.roles",
  "/admin/auditoria": "admin.audit",
};

function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="rounded-[var(--radius-xl)] border border-dashed border-[var(--color-border-strong)] bg-[var(--color-bg-elevated)] px-12 py-10">
        <h2 className="text-lg font-semibold text-[var(--color-fg)]">{title}</h2>
        <p className="mt-2 max-w-sm text-sm text-[var(--color-fg-muted)]">
          Módulo preparado. Se implementará con persistencia y reglas de negocio en la
          siguiente fase.
        </p>
      </div>
    </div>
  );
}

function ForbiddenPage({ onGoHome }: { onGoHome: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-danger-bg)] mb-4">
        <Shield className="h-6 w-6 text-[var(--color-danger)]" />
      </div>
      <h2 className="text-lg font-semibold">Acceso denegado</h2>
      <p className="mt-2 max-w-sm text-sm text-[var(--color-fg-muted)]">
        Su rol no tiene permiso para ver esta sección. Contacte al administrador si
        necesita acceso.
      </p>
      <Button className="mt-4" variant="outline" onClick={onGoHome}>
        Volver al Dashboard
      </Button>
    </div>
  );
}

function AuthenticatedApp() {
  const { can } = useAuth();
  const [path, setPath] = useState("/");

  const required = ROUTE_PERMISSIONS[path];
  const allowed = !required || can(required);
  const title = TITLES[path] ?? "Penalidades";

  // Si cambia el rol y la ruta actual ya no es permitida, ir al dashboard
  useEffect(() => {
    const req = ROUTE_PERMISSIONS[path];
    if (req && !can(req)) {
      setPath("/");
    }
  }, [can, path]);

  let content: React.ReactNode;
  if (!allowed) {
    content = <ForbiddenPage onGoHome={() => setPath("/")} />;
  } else {
    switch (path) {
      case "/":
        content = <DashboardPage />;
        break;
      case "/penalidades":
        content = (
          <FailuresListPage
            onNew={can("failures.create") ? () => setPath("/penalidades/nueva") : undefined}
          />
        );
        break;
      case "/penalidades/nueva":
        content = <NewFailurePage onBack={() => setPath("/penalidades")} />;
        break;
      case "/notas-debito/seguimiento":
        content = <PaymentTrackingPage />;
        break;
      case "/admin/roles":
      case "/admin/permisos":
        content = <RolesPage />;
        break;
      default:
        content = <PlaceholderPage title={title} />;
    }
  }

  return (
    <AppShell title={title} currentPath={path} onNavigate={setPath}>
      {content}
    </AppShell>
  );
}

function AppGate() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[var(--color-bg)]">
        <p className="text-sm text-[var(--color-fg-muted)]">Cargando...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return <AuthenticatedApp />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppGate />
    </AuthProvider>
  );
}
