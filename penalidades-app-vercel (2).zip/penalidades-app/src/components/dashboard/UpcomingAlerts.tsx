import { AlertTriangle, Clock, Bell } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const alerts = [
  {
    nd: "ND-2026-0012",
    provider: "G4S",
    due: "2026-09-22",
    days: 2,
    type: "URGENTE" as const,
  },
  {
    nd: "ND-2026-0009",
    provider: "PROSEGURIDAD",
    due: "2026-09-25",
    days: 5,
    type: "URGENTE" as const,
  },
  {
    nd: "ND-2026-0015",
    provider: "COMETAL",
    due: "2026-09-30",
    days: 10,
    type: "PREVENTIVA" as const,
  },
  {
    nd: "ND-2026-0007",
    provider: "SECURITY SALES",
    due: "2026-09-20",
    days: 0,
    type: "VENCIMIENTO" as const,
  },
  {
    nd: "ND-2026-0011",
    provider: "G4S",
    due: "2026-09-18",
    days: -2,
    type: "VENCIDO" as const,
  },
];

const typeConfig = {
  PREVENTIVA: { variant: "info" as const, icon: Bell, label: "Preventiva" },
  URGENTE: { variant: "warning" as const, icon: Clock, label: "Urgente" },
  VENCIMIENTO: { variant: "danger" as const, icon: AlertTriangle, label: "Vencimiento" },
  VENCIDO: { variant: "danger" as const, icon: AlertTriangle, label: "Vencido" },
};

export function UpcomingAlerts() {
  return (
    <Card className="h-full">
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle>Próximas alertas</CardTitle>
        <Badge variant="outline">{alerts.length} activas</Badge>
      </CardHeader>
      <CardContent className="pt-0 space-y-2">
        {alerts.map((a) => {
          const cfg = typeConfig[a.type];
          const Icon = cfg.icon;
          return (
            <div
              key={a.nd}
              className="flex items-center gap-3 rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-bg)] px-3 py-2.5"
            >
              <div
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-sm)] ${
                  a.type === "VENCIDO" || a.type === "VENCIMIENTO"
                    ? "bg-[var(--color-danger-bg)] text-[var(--color-danger)]"
                    : a.type === "URGENTE"
                    ? "bg-[var(--color-warning-bg)] text-[var(--color-warning)]"
                    : "bg-[var(--color-info-bg)] text-[var(--color-info)]"
                }`}
              >
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium tabular-nums">{a.nd}</span>
                  <Badge variant={cfg.variant}>{cfg.label}</Badge>
                </div>
                <p className="text-xs text-[var(--color-fg-muted)] truncate">
                  {a.provider} · Límite {a.due}
                  {a.days > 0
                    ? ` · ${a.days}d restantes`
                    : a.days === 0
                    ? " · Hoy"
                    : ` · ${Math.abs(a.days)}d vencido`}
                </p>
              </div>
              <Button variant="ghost" size="sm" className="shrink-0 text-xs">
                Ver
              </Button>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
