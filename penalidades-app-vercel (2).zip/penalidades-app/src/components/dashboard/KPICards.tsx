import {
  FileWarning,
  FileText,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Banknote,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils/cn";

interface KPI {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ReactNode;
  tone?: "default" | "warning" | "danger" | "success" | "primary";
}

const toneStyles = {
  default: "bg-[var(--color-bg-subtle)] text-[var(--color-fg-muted)]",
  primary: "bg-[var(--color-primary-muted)] text-[var(--color-primary)]",
  warning: "bg-[var(--color-warning-bg)] text-[var(--color-warning)]",
  danger: "bg-[var(--color-danger-bg)] text-[var(--color-danger)]",
  success: "bg-[var(--color-success-bg)] text-[var(--color-success)]",
};

export function KPICards() {
  const kpis: KPI[] = [
    {
      label: "Total Faltas",
      value: 47,
      sub: "+3 este mes",
      icon: <FileWarning className="h-5 w-5" />,
      tone: "default",
    },
    {
      label: "Total ND",
      value: 31,
      sub: "12 activas",
      icon: <FileText className="h-5 w-5" />,
      tone: "primary",
    },
    {
      label: "Pendientes",
      value: 8,
      sub: "S/ 28,420",
      icon: <Clock className="h-5 w-5" />,
      tone: "warning",
    },
    {
      label: "Vencidos",
      value: 4,
      sub: "S/ 15,735",
      icon: <AlertTriangle className="h-5 w-5" />,
      tone: "danger",
    },
    {
      label: "Pagados",
      value: 19,
      sub: "S/ 89,210",
      icon: <CheckCircle2 className="h-5 w-5" />,
      tone: "success",
    },
    {
      label: "Monto total",
      value: "S/ 133,365",
      sub: "Año 2026",
      icon: <Banknote className="h-5 w-5" />,
      tone: "default",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
      {kpis.map((kpi) => (
        <Card key={kpi.label} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div
                className={cn(
                  "flex h-9 w-9 items-center justify-center rounded-[var(--radius-md)]",
                  toneStyles[kpi.tone ?? "default"]
                )}
              >
                {kpi.icon}
              </div>
            </div>
            <p className="mt-3 text-2xl font-semibold tracking-tight text-[var(--color-fg)] tabular-nums">
              {kpi.value}
            </p>
            <p className="mt-0.5 text-xs font-medium text-[var(--color-fg-muted)]">
              {kpi.label}
            </p>
            {kpi.sub && (
              <p className="mt-1 text-[11px] text-[var(--color-fg-subtle)]">
                {kpi.sub}
              </p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
