# Desplegar Módulo de Penalidades en Vercel

Esta es la **interfaz UI** (frontend con datos demo). No incluye aún backend/Supabase/Neon en producción; sirve para revisar el diseño, navegación, formularios y dashboard.

---

## Opción rápida: Vercel (recomendado)

### 1. Descargar el ZIP
Archivo: `penalidades-app-vercel.zip` (en la carpeta del proyecto / artifacts).

### 2. Subir a GitHub (recomendado)
1. Crea un repositorio vacío en GitHub.
2. Descomprime el ZIP.
3. En la carpeta `penalidades-app`:

```bash
cd penalidades-app
git init
git add .
git commit -m "UI Módulo de Penalidades"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/penalidades-app.git
git push -u origin main
```

### 3. Conectar en Vercel
1. Entra a [vercel.com](https://vercel.com) e inicia sesión.
2. **Add New Project** → Importa el repositorio de GitHub.
3. Framework Preset: **Vite**.
4. Build Command: `npm run build`
5. Output Directory: `dist`
6. Install Command: `npm install`
7. Deploy.

Vercel detectará `vercel.json` (SPA rewrites) automáticamente.

### 4. Alternativa sin GitHub
En Vercel → **Add New** → **Project** → pestaña **Upload** (o CLI):

```bash
cd penalidades-app
npm install
npm i -g vercel
vercel
```

Sigue las preguntas (link a cuenta, scope, etc.).

---

## Probar en local antes de desplegar

```bash
cd penalidades-app
npm install
npm run dev
```

Abre `http://localhost:3000` (o el puerto que indique Vite).

Build de producción local:

```bash
npm run build
npm run preview
```

---

## Qué verás en la app

| Pantalla | Contenido |
|----------|-----------|
| Dashboard | KPIs, gráficos, alertas próximas |
| Listado de Faltas | Tabla con datos demo |
| Nueva Falta | Formulario con cálculo de tarifa (367 / 5245 / 400) |
| Seguimiento de Pagos | Estados Pendiente / Vencido / Pagado |
| Resto del menú | Placeholders listos para conectar |

Navegación por el sidebar (Penalidades, Notas de Débito, etc.).

---

## Notas importantes

- **Datos demo**: los listados y KPIs son estáticos para la UI. La persistencia real (PostgreSQL / Neon / Supabase) se conecta en fases posteriores.
- **Auth**: aún no está activa; el header muestra “Admin Demo”.
- El archivo `migrations/0001_schema.sql` es el schema completo para cuando conectes la base de datos.

Cuando quieras, en Grok seguimos con **roles y autenticación** (opción 2) sin afectar este ZIP de Vercel.
