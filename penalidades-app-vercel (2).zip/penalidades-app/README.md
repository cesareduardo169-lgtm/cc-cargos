# Módulo de Penalidades — Aplicación Empresarial

Sistema web para la gestión integral de penalidades contractuales aplicadas a proveedores de seguridad.

**Estado actual:** Fundación sólida (Fases 1–2 completadas).  
Listo para continuar con Auth, Catálogos, Registro de Faltas y el resto de módulos.

---

## Arquitectura adaptada al entorno Grok Build

| Requerido originalmente | Implementación en este entorno |
|-------------------------|--------------------------------|
| Next.js                 | **TanStack Start** (React + Vite + file-based routing) |
| Supabase PostgreSQL     | **Neon Postgres** (con fallback PGLite en preview) |
| Supabase Auth           | **Better Auth** + Grok Auth Broker (Google / X / email-password) |
| Supabase Storage        | Preparado (filesystem / S3 posterior). Buckets conceptuales: `descargos`, `notas-debito`, `xml`, `pagos` |
| Vercel                  | Deploy nativo de la plataforma Grok Build |
| Row Level Security      | Autorización en Server Functions + políticas de rol |

La lógica de negocio, correlativos, tarifas, días hábiles y umbral contractual están implementados exactamente según la especificación funcional entregada.

---

## Estructura del proyecto

```
penalidades-app/
├── migrations/
│   └── 0001_schema.sql          # Schema completo + seed + funciones + triggers
├── src/
│   ├── types/index.ts           # Tipos TypeScript alineados al schema
│   ├── lib/
│   │   ├── services/
│   │   │   ├── tariff.ts        # calculatePenalty() + umbral contractual
│   │   │   ├── dates.ts         # addBusinessDays / due date / alert types
│   │   │   └── email.ts         # EmailService + plantillas 10/5/0
│   │   ├── db/                  # (pendiente) getSql helper
│   │   └── validations/         # (pendiente) Zod schemas
│   ├── components/              # UI (pendiente)
│   ├── routes/                  # Rutas TanStack (pendiente)
│   └── styles/
├── seed/                        # Datos DEMO adicionales (pendiente)
└── README.md
```

---

## Schema SQL — resumen

### Tablas principales
- `providers`, `service_types`, `failure_categories`, `locations`
- `departments` → `provinces` → `districts`
- `tariffs` (versionadas, nunca sobrescritas destructivamente)
- `service_failures` (número `FLT-YYYY-NNNN`, costo congelado)
- `debit_notes` (número `ND-YYYY-NNNN`, due_date = +30 días hábiles)
- `payments`
- `notifications` (prevención de duplicados por `unique_key`)
- `in_app_notifications`
- `holidays`, `system_config`, `audit_logs`, `sequence_counters`

### Funciones de base de datos
| Función | Propósito |
|---------|-----------|
| `generate_failure_number()` | Correlativo seguro `FLT-YYYY-NNNN` (reinicia por año) |
| `generate_debit_note_number()` | Correlativo seguro `ND-YYYY-NNNN` |
| `add_business_days(date, n)` | Suma días hábiles (excluye sáb/dom + feriados) |
| `get_current_tariff(...)` | Busca tarifa vigente con prioridad específica > genérica |
| `check_contractual_threshold(provider)` | Cuenta faltas; umbral 13 solo alerta |

### Tarifas iniciales (seed)
| Categoría | Red de Agencia | Sede Principal |
|-----------|---------------:|---------------:|
| Falta Grave | S/ 367.00 | S/ 367.00 |
| Faltas Regulatorias | S/ 5,245.00 | S/ 5,245.00 |
| Faltas en el Servicio | S/ 5,245.00 | S/ 5,245.00 |
| Tardanzas | S/ 5,245.00 | S/ 5,245.00 |
| Personal no Idóneo | S/ 5,245.00 | **S/ 400.00** |

El umbral de 13 faltas **no incrementa** el costo; solo genera alerta contractual.

---

## Reglas de negocio protegidas

1. **Costo histórico congelado** — `penalty_cost` se guarda al momento del registro. Nunca se recalcula.
2. **30 días hábiles** — no se usan días calendario.
3. **Alertas exactas 10 / 5 / 0** — no se envían duplicados (tabla `notifications.unique_key`).
4. **Umbral 13** — solo alerta, sin cambio de tarifa.
5. **Correlativos concurrentes** — generados en base de datos con `ON CONFLICT` + contador por año.

---

## Próximos pasos (orden de construcción)

### FASE 3 — Auth + Roles
- Activar Better Auth (`VITE_AUTH_ENABLED`).
- Tabla de perfiles / roles (`ADMIN`, `CONTROL_INTERNO`, `FINANZAS`, `CONSULTA`).
- Middleware de autorización en Server Functions.

### FASE 4 — Catálogos
- CRUD de Proveedores, Tipos de Servicio, Categorías, Ubicaciones, Tarifas.
- Geografía dependiente (Depto → Provincia → Distrito).

### FASE 5 — Registro de Faltas
- Formulario completo.
- Autocompletado de costo vía `calculatePenalty()`.
- Generación de `FLT-YYYY-NNNN`.
- Upload de descargo.
- Alerta de umbral contractual.

### FASE 6–8 — ND, Pagos, Alertas
- Registro de Nota de Débito + cálculo de `due_date`.
- Seguimiento de pagos + estados.
- Motor diario de alertas (cron / scheduled function).

### FASE 9–11 — Dashboard, Reportes, Auditoría
- KPIs en tiempo real.
- Gráficos (categoría, proveedor, evolución).
- Exportación Excel / CSV / PDF.
- Log de auditoría completo.

---

## Cómo continuar

1. Revisar `migrations/0001_schema.sql` y `src/types/index.ts`.
2. Confirmar que las reglas de tarifa y umbral coinciden con la especificación.
3. Indicar si se desea:
   - Continuar con **Fase 3 (Auth + Roles)**
   - O priorizar el **scaffold completo de TanStack Start + UI base** primero.

Una vez aprobado el schema y la estructura, se avanza módulo por módulo sin romper lo ya construido.

---

## Variables de entorno (conceptual)

```
# Públicas (cliente)
VITE_AUTH_ENABLED=true

# Servidor (inyectadas por la plataforma o configuradas)
DATABASE_URL=                 # Neon (automático en deploy)
EMAIL_PROVIDER=console        # console | resend | sendgrid | ses
RESEND_API_KEY=               # si se usa Resend
```

Nunca colocar `service_role` ni secretos en el repositorio.

---

**Prioridades respetadas:** Integridad de datos → Seguridad → Reglas de negocio → Persistencia → Automatización → Auditoría → UX → Escalabilidad.
