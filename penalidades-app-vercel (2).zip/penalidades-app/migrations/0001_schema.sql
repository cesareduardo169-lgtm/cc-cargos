-- ============================================================
-- Módulo de Penalidades — Schema PostgreSQL (Neon compatible)
-- Versión: 1.0.0
-- Compatible con: Neon Postgres / PGLite
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";  -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- ENUMS
-- ============================================================

DO $$ BEGIN
  CREATE TYPE payment_status AS ENUM ('PENDIENTE', 'VENCIDO', 'PAGADO');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE alert_type AS ENUM (
    'RECORDATORIO_PREVENTIVO',  -- 10 días
    'AVISO_URGENTE',            -- 5 días
    'VENCIMIENTO'               -- 0 días
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE audit_action AS ENUM (
    'LOGIN', 'LOGOUT',
    'CREATE', 'UPDATE', 'DELETE', 'SOFT_DELETE',
    'UPLOAD', 'DOWNLOAD',
    'CHANGE_STATUS', 'REGISTER_PAYMENT',
    'CREATE_ND', 'SEND_NOTIFICATION',
    'CHANGE_TARIFF', 'VIEW'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE user_role AS ENUM (
    'ADMIN',
    'CONTROL_INTERNO',
    'FINANZAS',
    'CONSULTA'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ============================================================
-- TABLAS DE CATÁLOGOS
-- ============================================================

-- Proveedores
CREATE TABLE IF NOT EXISTS providers (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          VARCHAR(50) NOT NULL UNIQUE,
  name          VARCHAR(150) NOT NULL,
  legal_name    VARCHAR(200),
  ruc           VARCHAR(20),
  contact_ops_email   VARCHAR(255),
  contact_mgmt_email  VARCHAR(255),
  contact_finance_email VARCHAR(255),
  phone         VARCHAR(30),
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    UUID,
  updated_by    UUID,
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_providers_code ON providers(code);
CREATE INDEX IF NOT EXISTS idx_providers_active ON providers(is_active) WHERE deleted_at IS NULL;

-- Tipos de Servicio
CREATE TABLE IF NOT EXISTS service_types (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          VARCHAR(50) NOT NULL UNIQUE,
  name          VARCHAR(100) NOT NULL,
  description   TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    UUID,
  updated_by    UUID,
  deleted_at    TIMESTAMPTZ
);

-- Categorías de Falta
CREATE TABLE IF NOT EXISTS failure_categories (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          VARCHAR(50) NOT NULL UNIQUE,
  name          VARCHAR(100) NOT NULL,
  description   TEXT,
  severity      SMALLINT DEFAULT 1, -- 1=leve ... 5=grave
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    UUID,
  updated_by    UUID,
  deleted_at    TIMESTAMPTZ
);

-- Ubicaciones
CREATE TABLE IF NOT EXISTS locations (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          VARCHAR(50) NOT NULL UNIQUE,
  name          VARCHAR(100) NOT NULL,
  description   TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by    UUID,
  updated_by    UUID,
  deleted_at    TIMESTAMPTZ
);

-- ============================================================
-- GEOGRAFÍA (Perú)
-- ============================================================

CREATE TABLE IF NOT EXISTS departments (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          VARCHAR(10) NOT NULL UNIQUE,
  name          VARCHAR(100) NOT NULL,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS provinces (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id UUID NOT NULL REFERENCES departments(id),
  code          VARCHAR(10) NOT NULL,
  name          VARCHAR(100) NOT NULL,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(department_id, code)
);

CREATE INDEX IF NOT EXISTS idx_provinces_dept ON provinces(department_id);

CREATE TABLE IF NOT EXISTS districts (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  province_id   UUID NOT NULL REFERENCES provinces(id),
  code          VARCHAR(10) NOT NULL,
  name          VARCHAR(100) NOT NULL,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(province_id, code)
);

CREATE INDEX IF NOT EXISTS idx_districts_prov ON districts(province_id);

-- ============================================================
-- TARIFAS (con versionamiento)
-- ============================================================

CREATE TABLE IF NOT EXISTS tariffs (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id       UUID REFERENCES providers(id),          -- NULL = aplica a todos
  category_id       UUID NOT NULL REFERENCES failure_categories(id),
  location_id       UUID NOT NULL REFERENCES locations(id),
  service_type_id   UUID REFERENCES service_types(id),      -- NULL = aplica a todos
  cost              DECIMAL(12,2) NOT NULL CHECK (cost >= 0),
  currency          VARCHAR(3) NOT NULL DEFAULT 'PEN',
  effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to      DATE,                                    -- NULL = vigente
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by        UUID,
  updated_by        UUID,
  -- Constraint de unicidad lógica (permite histórico)
  CONSTRAINT uq_tariff_combo UNIQUE NULLS NOT DISTINCT (
    provider_id, category_id, location_id, service_type_id, effective_from
  )
);

CREATE INDEX IF NOT EXISTS idx_tariffs_lookup 
  ON tariffs(provider_id, category_id, location_id, service_type_id, is_active, effective_from DESC)
  WHERE is_active = TRUE;

CREATE INDEX IF NOT EXISTS idx_tariffs_category ON tariffs(category_id);
CREATE INDEX IF NOT EXISTS idx_tariffs_location ON tariffs(location_id);

-- ============================================================
-- FALTAS DEL SERVICIO
-- ============================================================

CREATE TABLE IF NOT EXISTS service_failures (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  failure_number    VARCHAR(20) NOT NULL UNIQUE,           -- FLT-YYYY-NNNN
  registered_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  provider_id       UUID NOT NULL REFERENCES providers(id),
  service_type_id   UUID NOT NULL REFERENCES service_types(id),
  category_id       UUID NOT NULL REFERENCES failure_categories(id),
  location_id       UUID NOT NULL REFERENCES locations(id),
  
  agency            VARCHAR(150),
  cod_topaz         VARCHAR(50),
  department_id     UUID REFERENCES departments(id),
  province_id       UUID REFERENCES provinces(id),
  district_id       UUID REFERENCES districts(id),
  
  observation       TEXT,
  provider_defense  TEXT,                                   -- descargo textual
  
  -- Costo congelado al momento del registro (auditoría histórica)
  penalty_cost      DECIMAL(12,2) NOT NULL,
  tariff_id         UUID REFERENCES tariffs(id),            -- referencia a la tarifa usada
  
  -- Documentos
  defense_file_path VARCHAR(500),
  defense_file_name VARCHAR(255),
  defense_file_mime VARCHAR(100),
  
  -- Estado de flujo
  has_debit_note    BOOLEAN NOT NULL DEFAULT FALSE,
  
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by        UUID,
  updated_by        UUID,
  deleted_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_failures_number ON service_failures(failure_number);
CREATE INDEX IF NOT EXISTS idx_failures_provider ON service_failures(provider_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_failures_category ON service_failures(category_id);
CREATE INDEX IF NOT EXISTS idx_failures_date ON service_failures(registered_at DESC);
CREATE INDEX IF NOT EXISTS idx_failures_location ON service_failures(location_id);

-- ============================================================
-- NOTAS DE DÉBITO
-- ============================================================

CREATE TABLE IF NOT EXISTS debit_notes (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nd_number             VARCHAR(20) NOT NULL UNIQUE,       -- ND-YYYY-NNNN
  accounting_date       DATE NOT NULL,                     -- Fecha de registro contable
  external_nd_number    VARCHAR(50),                       -- Número de la ND del proveedor/contabilidad
  
  provider_id           UUID NOT NULL REFERENCES providers(id),
  category_id           UUID NOT NULL REFERENCES failure_categories(id),
  location_id           UUID NOT NULL REFERENCES locations(id),
  
  -- Relación opcional con falta(s)
  failure_id            UUID REFERENCES service_failures(id),
  
  delivery_date         DATE,                              -- Fecha de entrega al proveedor
  due_date              DATE NOT NULL,                     -- Fecha límite de pago (calculada)
  
  amount                DECIMAL(12,2) NOT NULL,
  currency              VARCHAR(3) NOT NULL DEFAULT 'PEN',
  
  status                payment_status NOT NULL DEFAULT 'PENDIENTE',
  
  -- Archivos
  nd_file_path          VARCHAR(500),
  nd_file_name          VARCHAR(255),
  nd_file_mime          VARCHAR(100),
  xml_file_path         VARCHAR(500),
  xml_file_name         VARCHAR(255),
  
  notes                 TEXT,
  
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID,
  updated_by            UUID,
  deleted_at            TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_nd_number ON debit_notes(nd_number);
CREATE INDEX IF NOT EXISTS idx_nd_provider ON debit_notes(provider_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_nd_status ON debit_notes(status) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_nd_due_date ON debit_notes(due_date);
CREATE INDEX IF NOT EXISTS idx_nd_accounting ON debit_notes(accounting_date DESC);

-- ============================================================
-- PAGOS
-- ============================================================

CREATE TABLE IF NOT EXISTS payments (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  debit_note_id     UUID NOT NULL REFERENCES debit_notes(id),
  payment_date      DATE NOT NULL,
  amount            DECIMAL(12,2) NOT NULL CHECK (amount > 0),
  currency          VARCHAR(3) NOT NULL DEFAULT 'PEN',
  payment_method    VARCHAR(50),                           -- Transferencia, Cheque, etc.
  reference         VARCHAR(100),
  observation       TEXT,
  
  support_file_path VARCHAR(500),
  support_file_name VARCHAR(255),
  support_file_mime VARCHAR(100),
  
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by        UUID,
  updated_by        UUID,
  deleted_at        TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_payments_nd ON payments(debit_note_id) WHERE deleted_at IS NULL;

-- ============================================================
-- NOTIFICACIONES / ALERTAS
-- ============================================================

CREATE TABLE IF NOT EXISTS notifications (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  debit_note_id     UUID NOT NULL REFERENCES debit_notes(id),
  alert_type        alert_type NOT NULL,
  days_remaining    INTEGER NOT NULL,                      -- 10, 5, 0
  
  sent_at           TIMESTAMPTZ,
  sent_to           TEXT[],                                -- emails
  subject           VARCHAR(300),
  body_preview      TEXT,
  
  status            VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, SENT, FAILED
  error_message     TEXT,
  
  -- Control de duplicados
  unique_key        VARCHAR(100) NOT NULL,                 -- nd_id + alert_type
  
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  CONSTRAINT uq_notification_unique UNIQUE (unique_key)
);

CREATE INDEX IF NOT EXISTS idx_notif_nd ON notifications(debit_note_id);
CREATE INDEX IF NOT EXISTS idx_notif_type ON notifications(alert_type);
CREATE INDEX IF NOT EXISTS idx_notif_status ON notifications(status);

-- ============================================================
-- NOTIFICACIONES INTERNAS (in-app)
-- ============================================================

CREATE TABLE IF NOT EXISTS in_app_notifications (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID,                                  -- si es null = broadcast a roles
  role_target       user_role,
  title             VARCHAR(200) NOT NULL,
  message           TEXT NOT NULL,
  link              VARCHAR(300),
  is_read           BOOLEAN NOT NULL DEFAULT FALSE,
  related_nd_id     UUID REFERENCES debit_notes(id),
  related_failure_id UUID REFERENCES service_failures(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_inapp_user ON in_app_notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_inapp_role ON in_app_notifications(role_target, is_read);

-- ============================================================
-- FERIADOS (para cálculo de días hábiles futuro)
-- ============================================================

CREATE TABLE IF NOT EXISTS holidays (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  holiday_date  DATE NOT NULL UNIQUE,
  name          VARCHAR(150) NOT NULL,
  is_national   BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- CONFIGURACIÓN DEL SISTEMA
-- ============================================================

CREATE TABLE IF NOT EXISTS system_config (
  key           VARCHAR(100) PRIMARY KEY,
  value         TEXT NOT NULL,
  description   TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by    UUID
);

-- ============================================================
-- AUDITORÍA
-- ============================================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID,
  user_email    VARCHAR(255),
  action        audit_action NOT NULL,
  table_name    VARCHAR(100),
  record_id     UUID,
  old_data      JSONB,
  new_data      JSONB,
  ip_address    INET,
  user_agent    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_table ON audit_logs(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_logs(created_at DESC);

-- ============================================================
-- CONTADORES DE CORRELATIVOS (para generación segura)
-- ============================================================

CREATE TABLE IF NOT EXISTS sequence_counters (
  name          VARCHAR(50) NOT NULL,
  year          INTEGER NOT NULL,
  last_value    INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (name, year)
);

-- ============================================================
-- FUNCIONES DE NEGOCIO
-- ============================================================

-- Generar número de falta: FLT-YYYY-NNNN
CREATE OR REPLACE FUNCTION generate_failure_number()
RETURNS VARCHAR(20)
LANGUAGE plpgsql
AS $$
DECLARE
  current_year INTEGER := EXTRACT(YEAR FROM CURRENT_DATE);
  next_val INTEGER;
BEGIN
  INSERT INTO sequence_counters (name, year, last_value)
  VALUES ('FAILURE', current_year, 1)
  ON CONFLICT (name, year)
  DO UPDATE SET last_value = sequence_counters.last_value + 1
  RETURNING last_value INTO next_val;
  
  RETURN 'FLT-' || current_year || '-' || LPAD(next_val::TEXT, 4, '0');
END;
$$;

-- Generar número de ND: ND-YYYY-NNNN
CREATE OR REPLACE FUNCTION generate_debit_note_number()
RETURNS VARCHAR(20)
LANGUAGE plpgsql
AS $$
DECLARE
  current_year INTEGER := EXTRACT(YEAR FROM CURRENT_DATE);
  next_val INTEGER;
BEGIN
  INSERT INTO sequence_counters (name, year, last_value)
  VALUES ('DEBIT_NOTE', current_year, 1)
  ON CONFLICT (name, year)
  DO UPDATE SET last_value = sequence_counters.last_value + 1
  RETURNING last_value INTO next_val;
  
  RETURN 'ND-' || current_year || '-' || LPAD(next_val::TEXT, 4, '0');
END;
$$;

-- Calcular días hábiles (excluye sábados y domingos; feriados opcionales)
CREATE OR REPLACE FUNCTION add_business_days(start_date DATE, days INTEGER)
RETURNS DATE
LANGUAGE plpgsql
AS $$
DECLARE
  result_date DATE := start_date;
  added INTEGER := 0;
  direction INTEGER := CASE WHEN days >= 0 THEN 1 ELSE -1 END;
  abs_days INTEGER := ABS(days);
BEGIN
  WHILE added < abs_days LOOP
    result_date := result_date + direction;
    -- Excluir sábados (6) y domingos (0)
    IF EXTRACT(DOW FROM result_date) NOT IN (0, 6) THEN
      -- Verificar si no es feriado (si la tabla tiene datos)
      IF NOT EXISTS (
        SELECT 1 FROM holidays h WHERE h.holiday_date = result_date
      ) THEN
        added := added + 1;
      END IF;
    END IF;
  END LOOP;
  RETURN result_date;
END;
$$;

-- Obtener tarifa vigente
CREATE OR REPLACE FUNCTION get_current_tariff(
  p_provider_id UUID,
  p_category_id UUID,
  p_location_id UUID,
  p_service_type_id UUID DEFAULT NULL
)
RETURNS TABLE (
  tariff_id UUID,
  cost DECIMAL(12,2)
)
LANGUAGE plpgsql
STABLE
AS $$
BEGIN
  RETURN QUERY
  SELECT t.id, t.cost
  FROM tariffs t
  WHERE t.category_id = p_category_id
    AND t.location_id = p_location_id
    AND t.is_active = TRUE
    AND (t.effective_to IS NULL OR t.effective_to >= CURRENT_DATE)
    AND t.effective_from <= CURRENT_DATE
    AND (t.provider_id IS NULL OR t.provider_id = p_provider_id)
    AND (t.service_type_id IS NULL OR t.service_type_id = p_service_type_id)
  ORDER BY 
    -- Prioridad: tarifa específica de proveedor > genérica
    CASE WHEN t.provider_id IS NOT NULL THEN 0 ELSE 1 END,
    CASE WHEN t.service_type_id IS NOT NULL THEN 0 ELSE 1 END,
    t.effective_from DESC
  LIMIT 1;
END;
$$;

-- Contar faltas acumuladas por proveedor (umbral contractual)
CREATE OR REPLACE FUNCTION check_contractual_threshold(p_provider_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
  cnt INTEGER;
BEGIN
  SELECT COUNT(*) INTO cnt
  FROM service_failures
  WHERE provider_id = p_provider_id
    AND deleted_at IS NULL;
  RETURN cnt;
END;
$$;

-- Actualizar estado de ND (vencigger helper)
CREATE OR REPLACE FUNCTION update_debit_note_status()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.status = 'PAGADO' THEN
    RETURN NEW;
  END IF;
  
  IF CURRENT_DATE > NEW.due_date THEN
    NEW.status := 'VENCIDO';
  ELSE
    NEW.status := 'PENDIENTE';
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger updated_at genérico
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Aplicar triggers updated_at
DO $$
DECLARE
  t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'providers', 'service_types', 'failure_categories', 'locations',
    'tariffs', 'service_failures', 'debit_notes', 'payments'
  ]
  LOOP
    EXECUTE format('
      DROP TRIGGER IF EXISTS trg_%s_updated_at ON %I;
      CREATE TRIGGER trg_%s_updated_at
        BEFORE UPDATE ON %I
        FOR EACH ROW EXECUTE FUNCTION set_updated_at();
    ', t, t, t, t);
  END LOOP;
END;
$$;

-- Trigger para recalcular estado al insert/update de ND
DROP TRIGGER IF EXISTS trg_nd_status ON debit_notes;
CREATE TRIGGER trg_nd_status
  BEFORE INSERT OR UPDATE OF due_date, status ON debit_notes
  FOR EACH ROW
  WHEN (NEW.status IS DISTINCT FROM 'PAGADO')
  EXECUTE FUNCTION update_debit_note_status();

-- ============================================================
-- DATOS INICIALES (SEED)
-- ============================================================

-- Configuración del sistema
INSERT INTO system_config (key, value, description) VALUES
  ('business_days_payment', '30', 'Días hábiles para fecha límite de pago'),
  ('alert_days_preventive', '10', 'Días para alerta preventiva'),
  ('alert_days_urgent', '5', 'Días para alerta urgente'),
  ('alert_days_due', '0', 'Día de vencimiento'),
  ('contractual_threshold', '13', 'Umbral de faltas acumuladas para alerta contractual'),
  ('base_invoice_amount', '524500.00', 'Monto base de factura sin IGV (referencia 1%)'),
  ('company_name', 'Empresa de Seguridad', 'Nombre de la empresa usuaria'),
  ('currency', 'PEN', 'Moneda por defecto')
ON CONFLICT (key) DO NOTHING;

-- Proveedores
INSERT INTO providers (id, code, name, contact_ops_email, contact_mgmt_email) VALUES
  ('a0000001-0000-4000-8000-000000000001', 'G4S', 'G4S', 'ops@g4s.example.com', 'gerencia@g4s.example.com'),
  ('a0000001-0000-4000-8000-000000000002', 'PROSEGURIDAD', 'PROSEGURIDAD', 'ops@proseguridad.example.com', 'gerencia@proseguridad.example.com'),
  ('a0000001-0000-4000-8000-000000000003', 'COMETAL', 'COMETAL', 'ops@cometal.example.com', 'gerencia@cometal.example.com'),
  ('a0000001-0000-4000-8000-000000000004', 'SECURITY_SALES', 'SECURITY SALES', 'ops@securitysales.example.com', 'gerencia@securitysales.example.com')
ON CONFLICT (code) DO NOTHING;

-- Tipos de Servicio
INSERT INTO service_types (id, code, name) VALUES
  ('b0000001-0000-4000-8000-000000000001', 'FIJO', 'Servicio Fijo'),
  ('b0000001-0000-4000-8000-000000000002', 'ESPECIAL', 'Servicio Especial'),
  ('b0000001-0000-4000-8000-000000000003', 'LLAVES', 'Proyecto de Llaves')
ON CONFLICT (code) DO NOTHING;

-- Categorías de Falta
INSERT INTO failure_categories (id, code, name, severity) VALUES
  ('c0000001-0000-4000-8000-000000000001', 'GRAVE', 'Falta Grave', 5),
  ('c0000001-0000-4000-8000-000000000002', 'SERVICIO', 'Faltas en el Servicio', 3),
  ('c0000001-0000-4000-8000-000000000003', 'REGULATORIA', 'Faltas Regulatorias', 4),
  ('c0000001-0000-4000-8000-000000000004', 'NO_IDONEO', 'Personal no Idóneo', 4),
  ('c0000001-0000-4000-8000-000000000005', 'TARDANZA', 'Tardanzas', 2)
ON CONFLICT (code) DO NOTHING;

-- Ubicaciones
INSERT INTO locations (id, code, name) VALUES
  ('d0000001-0000-4000-8000-000000000001', 'RED_AGENCIA', 'Red de Agencia'),
  ('d0000001-0000-4000-8000-000000000002', 'SEDE_PRINCIPAL', 'Sede Principal')
ON CONFLICT (code) DO NOTHING;

-- Tarifas iniciales (según especificación)
-- Falta Grave: 367.00 ambas ubicaciones
INSERT INTO tariffs (provider_id, category_id, location_id, cost, effective_from, notes) VALUES
  (NULL, 'c0000001-0000-4000-8000-000000000001', 'd0000001-0000-4000-8000-000000000001', 367.00, '2025-01-01', 'Costo fijo contractual'),
  (NULL, 'c0000001-0000-4000-8000-000000000001', 'd0000001-0000-4000-8000-000000000002', 367.00, '2025-01-01', 'Costo fijo contractual');

-- Faltas Regulatorias, Servicio, Tardanzas: 5245.00 ambas
INSERT INTO tariffs (provider_id, category_id, location_id, cost, effective_from, notes) VALUES
  (NULL, 'c0000001-0000-4000-8000-000000000003', 'd0000001-0000-4000-8000-000000000001', 5245.00, '2025-01-01', '1% factura base sin IGV'),
  (NULL, 'c0000001-0000-4000-8000-000000000003', 'd0000001-0000-4000-8000-000000000002', 5245.00, '2025-01-01', '1% factura base sin IGV'),
  (NULL, 'c0000001-0000-4000-8000-000000000002', 'd0000001-0000-4000-8000-000000000001', 5245.00, '2025-01-01', '1% factura base sin IGV'),
  (NULL, 'c0000001-0000-4000-8000-000000000002', 'd0000001-0000-4000-8000-000000000002', 5245.00, '2025-01-01', '1% factura base sin IGV'),
  (NULL, 'c0000001-0000-4000-8000-000000000005', 'd0000001-0000-4000-8000-000000000001', 5245.00, '2025-01-01', '1% factura base sin IGV'),
  (NULL, 'c0000001-0000-4000-8000-000000000005', 'd0000001-0000-4000-8000-000000000002', 5245.00, '2025-01-01', '1% factura base sin IGV');

-- Personal no Idóneo: Red 5245 / Sede 400
INSERT INTO tariffs (provider_id, category_id, location_id, cost, effective_from, notes) VALUES
  (NULL, 'c0000001-0000-4000-8000-000000000004', 'd0000001-0000-4000-8000-000000000001', 5245.00, '2025-01-01', '1% factura base sin IGV'),
  (NULL, 'c0000001-0000-4000-8000-000000000004', 'd0000001-0000-4000-8000-000000000002', 400.00, '2025-01-01', 'Excepción fija Sede Principal');

-- Departamentos de ejemplo (Perú - muestra)
INSERT INTO departments (id, code, name) VALUES
  ('e0000001-0000-4000-8000-000000000001', '15', 'Lima'),
  ('e0000001-0000-4000-8000-000000000002', '04', 'Arequipa'),
  ('e0000001-0000-4000-8000-000000000003', '13', 'La Libertad')
ON CONFLICT (code) DO NOTHING;

INSERT INTO provinces (id, department_id, code, name) VALUES
  ('f0000001-0000-4000-8000-000000000001', 'e0000001-0000-4000-8000-000000000001', '1501', 'Lima'),
  ('f0000001-0000-4000-8000-000000000002', 'e0000001-0000-4000-8000-000000000001', '1507', 'Huaral'),
  ('f0000001-0000-4000-8000-000000000003', 'e0000001-0000-4000-8000-000000000002', '0401', 'Arequipa')
ON CONFLICT (department_id, code) DO NOTHING;

INSERT INTO districts (id, province_id, code, name) VALUES
  ('g0000001-0000-4000-8000-000000000001', 'f0000001-0000-4000-8000-000000000001', '150101', 'Lima'),
  ('g0000001-0000-4000-8000-000000000002', 'f0000001-0000-4000-8000-000000000001', '150122', 'Miraflores'),
  ('g0000001-0000-4000-8000-000000000003', 'f0000001-0000-4000-8000-000000000001', '150140', 'San Isidro'),
  ('g0000001-0000-4000-8000-000000000004', 'f0000001-0000-4000-8000-000000000002', '150701', 'Huaral')
ON CONFLICT (province_id, code) DO NOTHING;

-- ============================================================
-- COMENTARIOS FINALES
-- ============================================================
COMMENT ON TABLE service_failures IS 'Registro de faltas del servicio. El costo se congela al momento del registro.';
COMMENT ON TABLE tariffs IS 'Catálogo de tarifas con versionamiento histórico. Nunca se sobrescribe destructivamente.';
COMMENT ON TABLE debit_notes IS 'Notas de débito. Fecha límite = accounting_date + 30 días hábiles.';
COMMENT ON FUNCTION add_business_days IS 'Suma días hábiles excluyendo sábados, domingos y feriados configurados.';
COMMENT ON FUNCTION get_current_tariff IS 'Obtiene la tarifa vigente más específica para la combinación dada.';
COMMENT ON FUNCTION check_contractual_threshold IS 'Cuenta faltas acumuladas. Umbral de 13 solo genera alerta, no incrementa tarifa.';
