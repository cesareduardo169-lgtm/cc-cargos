-- ============================================================
-- Auth + Roles + Permisos — Módulo de Penalidades
-- Ejecutar después de 0001_schema.sql
-- ============================================================

-- Roles del sistema (enum ya existe en 0001: user_role)
-- ADMIN | CONTROL_INTERNO | FINANZAS | CONSULTA

-- Perfiles de usuario (extiende la identidad de auth)
CREATE TABLE IF NOT EXISTS profiles (
  id              UUID PRIMARY KEY,              -- mismo id que auth.users / better-auth user
  email           VARCHAR(255) NOT NULL UNIQUE,
  full_name       VARCHAR(200),
  role            user_role NOT NULL DEFAULT 'CONSULTA',
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by      UUID,
  updated_by      UUID,
  deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_profiles_active ON profiles(is_active) WHERE deleted_at IS NULL;

-- Catálogo de permisos (granular)
CREATE TABLE IF NOT EXISTS permissions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code            VARCHAR(80) NOT NULL UNIQUE,   -- ej. failures.create
  name            VARCHAR(150) NOT NULL,
  module          VARCHAR(50) NOT NULL,           -- failures | debit_notes | catalogs | reports | admin
  description     TEXT
);

-- Matriz rol → permisos
CREATE TABLE IF NOT EXISTS role_permissions (
  role            user_role NOT NULL,
  permission_id   UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role, permission_id)
);

-- Seed de permisos
INSERT INTO permissions (code, name, module, description) VALUES
  -- Dashboard
  ('dashboard.view',           'Ver dashboard',                    'dashboard',    'Acceso al panel de control'),
  -- Faltas
  ('failures.view',            'Ver faltas',                       'failures',     'Listar y ver detalle de faltas'),
  ('failures.create',          'Registrar faltas',                 'failures',     'Crear nuevas faltas'),
  ('failures.edit',            'Editar faltas',                    'failures',     'Modificar faltas existentes'),
  ('failures.delete',          'Eliminar faltas',                  'failures',     'Soft-delete de faltas'),
  ('failures.adjust_cost',     'Ajustar costo manual',             'failures',     'Override del costo calculado por tarifa'),
  -- Notas de débito
  ('debit_notes.view',         'Ver notas de débito',              'debit_notes',  'Listar y ver ND'),
  ('debit_notes.create',       'Registrar ND',                     'debit_notes',  'Crear notas de débito'),
  ('debit_notes.edit',         'Editar ND',                        'debit_notes',  'Modificar ND'),
  -- Pagos
  ('payments.view',            'Ver pagos',                        'payments',     'Ver seguimiento de pagos'),
  ('payments.register',        'Registrar pago',                   'payments',     'Marcar ND como pagada'),
  -- Alertas
  ('alerts.view',              'Ver alertas',                      'alerts',       'Ver alertas próximas y vencidas'),
  ('alerts.manage',            'Gestionar alertas',                'alerts',       'Reenviar / configurar alertas'),
  -- Catálogos
  ('catalogs.view',            'Ver catálogos',                    'catalogs',     'Consultar proveedores, tarifas, etc.'),
  ('catalogs.manage',          'Administrar catálogos',            'catalogs',     'CRUD de catálogos y tarifas'),
  -- Reportes
  ('reports.view',             'Ver reportes',                     'reports',      'Acceso a reportes y exportación'),
  -- Administración
  ('admin.users',              'Gestionar usuarios',               'admin',        'CRUD de usuarios y asignación de roles'),
  ('admin.roles',              'Gestionar roles',                  'admin',        'Ver matriz de permisos'),
  ('admin.audit',              'Ver auditoría',                    'admin',        'Consultar logs de auditoría'),
  ('admin.config',             'Configuración del sistema',        'admin',        'Parámetros globales')
ON CONFLICT (code) DO NOTHING;

-- Matriz de permisos por rol
-- ADMIN: todo
INSERT INTO role_permissions (role, permission_id)
SELECT 'ADMIN', id FROM permissions
ON CONFLICT DO NOTHING;

-- CONTROL_INTERNO: faltas + alertas + consultas + catálogos lectura
INSERT INTO role_permissions (role, permission_id)
SELECT 'CONTROL_INTERNO', id FROM permissions
WHERE code IN (
  'dashboard.view',
  'failures.view', 'failures.create', 'failures.edit',
  'debit_notes.view',
  'payments.view',
  'alerts.view', 'alerts.manage',
  'catalogs.view',
  'reports.view'
)
ON CONFLICT DO NOTHING;

-- FINANZAS: ND + pagos + consultas
INSERT INTO role_permissions (role, permission_id)
SELECT 'FINANZAS', id FROM permissions
WHERE code IN (
  'dashboard.view',
  'failures.view',
  'debit_notes.view', 'debit_notes.create', 'debit_notes.edit',
  'payments.view', 'payments.register',
  'alerts.view',
  'catalogs.view',
  'reports.view'
)
ON CONFLICT DO NOTHING;

-- CONSULTA: solo lectura
INSERT INTO role_permissions (role, permission_id)
SELECT 'CONSULTA', id FROM permissions
WHERE code IN (
  'dashboard.view',
  'failures.view',
  'debit_notes.view',
  'payments.view',
  'alerts.view',
  'catalogs.view',
  'reports.view'
)
ON CONFLICT DO NOTHING;

-- Helper: ¿tiene permiso?
CREATE OR REPLACE FUNCTION user_has_permission(p_user_id UUID, p_permission_code VARCHAR)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
  v_role user_role;
  v_ok BOOLEAN;
BEGIN
  SELECT role INTO v_role
  FROM profiles
  WHERE id = p_user_id
    AND is_active = TRUE
    AND deleted_at IS NULL;

  IF v_role IS NULL THEN
    RETURN FALSE;
  END IF;

  IF v_role = 'ADMIN' THEN
    RETURN TRUE;
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM role_permissions rp
    JOIN permissions p ON p.id = rp.permission_id
    WHERE rp.role = v_role
      AND p.code = p_permission_code
  ) INTO v_ok;

  RETURN COALESCE(v_ok, FALSE);
END;
$$;

COMMENT ON TABLE profiles IS 'Perfiles de usuario con rol. id = id del sistema de autenticación.';
COMMENT ON TABLE permissions IS 'Catálogo de permisos granulares por módulo.';
COMMENT ON TABLE role_permissions IS 'Matriz rol → permisos. ADMIN tiene todos por lógica en user_has_permission.';
COMMENT ON FUNCTION user_has_permission IS 'Valida permiso en backend/DB. Nunca confiar solo en el frontend.';
