# C&C Cargos — Sitio web corporativo

Página web profesional y moderna para **C&C Cargos**, empresa peruana de transporte de carga, paquetería y encomiendas.

## Identidad visual

- **Fondo:** Azul marino muy oscuro (`#0B1426` / `#060d1a`)
- **Acento:** Amarillo / dorado (`#F5C518`)
- **Texto:** Blanco y grises claros
- Tipografía: Outfit (titulares) + Inter (cuerpo)
- Banner y póster propios con camión, mapa de Perú y rutas doradas

## Archivos principales

| Archivo | Descripción |
|---------|-------------|
| `index.html` | Sitio completo (una sola página) |
| `assets/banner-cc-cargos.jpg` | Banner horizontal (hero) |
| `assets/poster-cc-cargos.jpg` | Versión vertical / póster |

## Secciones incluidas

1. Header fijo con logo C&C Cargos y menú responsive  
2. Hero con banner propio + mensaje “CONECTAMOS DESTINOS, ENTREGAMOS CONFIANZA” + CTAs  
3. Servicios: Transporte de carga, Paquetería, Encomiendas  
4. ¿Por qué elegir C&C Cargos?: Seguridad, Puntualidad, Seguimiento, Confianza  
5. Módulo de rastreo por número de envío (listo para API)  
6. Formulario de cotización  
7. Proceso: Solicitas → Cotizamos → Recogemos → Transportamos → Entregamos  
8. Soluciones logísticas empresariales (B2B)  
9. Contacto + botón flotante de WhatsApp  
10. Footer corporativo  

**Administrador:** Cesar Samillán Serrato  

## Cómo ver el sitio

Abre `index.html` en el navegador (doble clic) o sirve la carpeta:

```bash
npx serve .
# o
python3 -m http.server 8080
```

## Preparado para Supabase + Vercel

- Formulario de cotización y módulo de rastreo listos para conectar a **Supabase**.
- Sitio estático ideal para desplegar en **Vercel**.
- Contacto: +51 902 103 193 · cesar.samillan.s@ccargos.pe

---

© 2026 C&C Cargos · Identidad visual propia
