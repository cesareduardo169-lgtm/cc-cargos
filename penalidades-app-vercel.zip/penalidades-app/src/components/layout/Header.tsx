import { Bell, Search, User, LogOut, ChevronDown } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Badge } from "@/components/ui/badge";
import { MobileMenuButton } from "./Sidebar";

interface HeaderProps {
  title?: string;
  onMobileMenu?: () => void;
  notificationCount?: number;
}

export function Header({
  title = "Dashboard",
  onMobileMenu,
  notificationCount = 3,
}: HeaderProps) {
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-[var(--color-border)] bg-[var(--color-bg-elevated)] px-4 lg:px-6">
      {onMobileMenu && <MobileMenuButton onClick={onMobileMenu} />}

      <div className="flex-1 min-w-0">
        <h1 className="truncate text-base font-semibold text-[var(--color-fg)]">
          {title}
        </h1>
      </div>

      {/* Search (desktop) */}
      <div className="hidden md:flex relative w-64">
        <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-fg-subtle)]" />
        <input
          type="search"
          placeholder="Buscar falta, ND, proveedor..."
          className="h-8 w-full rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-bg)] pl-8 pr-3 text-sm placeholder:text-[var(--color-fg-subtle)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
        />
      </div>

      {/* Notifications */}
      <button
        type="button"
        className="relative rounded-[var(--radius-md)] p-2 text-[var(--color-fg-muted)] hover:bg-[var(--color-bg-subtle)] transition-colors"
        aria-label="Notificaciones"
      >
        <Bell className="h-4.5 w-4.5" />
        {notificationCount > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--color-danger)] px-1 text-[10px] font-semibold text-white">
            {notificationCount}
          </span>
        )}
      </button>

      {/* User */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setUserMenuOpen((v) => !v)}
          className="flex items-center gap-2 rounded-[var(--radius-md)] py-1 pl-1 pr-2 hover:bg-[var(--color-bg-subtle)] transition-colors"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-primary-muted)] text-[var(--color-primary-hover)]">
            <User className="h-4 w-4" />
          </div>
          <div className="hidden sm:flex flex-col items-start">
            <span className="text-xs font-medium text-[var(--color-fg)] leading-tight">
              Admin Demo
            </span>
            <span className="text-[10px] text-[var(--color-fg-muted)] leading-tight">
              ADMIN
            </span>
          </div>
          <ChevronDown className="hidden sm:block h-3.5 w-3.5 text-[var(--color-fg-subtle)]" />
        </button>

        {userMenuOpen && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setUserMenuOpen(false)}
            />
            <div className="absolute right-0 top-full z-50 mt-1 w-48 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-[var(--color-bg-elevated)] py-1 shadow-lg">
              <div className="border-b border-[var(--color-border)] px-3 py-2">
                <p className="text-sm font-medium">Admin Demo</p>
                <p className="text-xs text-[var(--color-fg-muted)]">
                  admin@empresa.pe
                </p>
                <Badge variant="primary" className="mt-1">
                  ADMIN
                </Badge>
              </div>
              <button
                type="button"
                className="flex w-full items-center gap-2 px-3 py-2 text-sm text-[var(--color-fg-muted)] hover:bg-[var(--color-bg-subtle)]"
                onClick={() => setUserMenuOpen(false)}
              >
                <User className="h-4 w-4" />
                Mi perfil
              </button>
              <button
                type="button"
                className="flex w-full items-center gap-2 px-3 py-2 text-sm text-[var(--color-danger)] hover:bg-[var(--color-danger-bg)]"
                onClick={() => setUserMenuOpen(false)}
              >
                <LogOut className="h-4 w-4" />
                Cerrar sesión
              </button>
            </div>
          </>
        )}
      </div>
    </header>
  );
}
