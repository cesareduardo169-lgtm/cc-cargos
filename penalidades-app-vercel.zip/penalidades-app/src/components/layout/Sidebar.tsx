import { useState } from "react";
import {
  LayoutDashboard,
  FileWarning,
  FileText,
  CreditCard,
  BookOpen,
  Bell,
  BarChart3,
  Settings,
  ChevronDown,
  ChevronRight,
  Shield,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

type NavItem = {
  label: string;
  href?: string;
  icon?: React.ReactNode;
  children?: { label: string; href: string }[];
};

const NAV: NavItem[] = [
  {
    label: "Dashboard",
    href: "/",
    icon: <LayoutDashboard className="h-4 w-4" />,
  },
  {
    label: "Penalidades",
    icon: <FileWarning className="h-4 w-4" />,
    children: [
      { label: "Registrar Falta", href: "/penalidades/nueva" },
      { label: "Listado de Faltas", href: "/penalidades" },
      { label: "Historial", href: "/penalidades/historial" },
    ],
  },
  {
    label: "Notas de Débito",
    icon: <FileText className="h-4 w-4" />,
    children: [
      { label: "Registrar ND", href: "/notas-debito/nueva" },
      { label: "Listado de ND", href: "/notas-debito" },
      { label: "Seguimiento de Pagos", href: "/notas-debito/seguimiento" },
    ],
  },
  {
    label: "Catálogos",
    icon: <BookOpen className="h-4 w-4" />,
    children: [
      { label: "Proveedores", href: "/catalogos/proveedores" },
      { label: "Tipos de Servicio", href: "/catalogos/tipos-servicio" },
      { label: "Categorías de Falta", href: "/catalogos/categorias" },
      { label: "Ubicaciones", href: "/catalogos/ubicaciones" },
      { label: "Tarifas", href: "/catalogos/tarifas" },
      { label: "Geografía", href: "/catalogos/geografia" },
    ],
  },
  {
    label: "Alertas",
    icon: <Bell className="h-4 w-4" />,
    children: [
      { label: "Próximas", href: "/alertas/proximas" },
      { label: "Vencidas", href: "/alertas/vencidas" },
      { label: "Historial", href: "/alertas/historial" },
    ],
  },
  {
    label: "Reportes",
    href: "/reportes",
    icon: <BarChart3 className="h-4 w-4" />,
  },
  {
    label: "Administración",
    icon: <Settings className="h-4 w-4" />,
    children: [
      { label: "Usuarios", href: "/admin/usuarios" },
      { label: "Roles", href: "/admin/roles" },
      { label: "Permisos", href: "/admin/permisos" },
      { label: "Auditoría", href: "/admin/auditoria" },
    ],
  },
];

interface SidebarProps {
  currentPath?: string;
  onNavigate?: (href: string) => void;
  collapsed?: boolean;
  onToggle?: () => void;
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

export function Sidebar({
  currentPath = "/",
  onNavigate,
  collapsed = false,
  mobileOpen = false,
  onMobileClose,
}: SidebarProps) {
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    Penalidades: true,
    "Notas de Débito": true,
  });

  const toggleGroup = (label: string) => {
    setOpenGroups((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  const isActive = (href?: string) =>
    href === currentPath || (href !== "/" && currentPath.startsWith(href ?? ""));

  const handleNav = (href: string) => {
    onNavigate?.(href);
    onMobileClose?.();
  };

  const content = (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="flex h-14 items-center gap-2.5 border-b border-white/10 px-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-primary)]">
          <Shield className="h-4 w-4 text-white" />
        </div>
        {!collapsed && (
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[var(--color-fg-on-dark)] leading-tight">
              Penalidades
            </span>
            <span className="text-[10px] text-[var(--color-fg-on-dark-muted)] leading-tight">
              Gestión contractual
            </span>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5">
        {NAV.map((item) => {
          if (item.children) {
            const open = openGroups[item.label] ?? false;
            return (
              <div key={item.label}>
                <button
                  type="button"
                  onClick={() => toggleGroup(item.label)}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-[var(--radius-md)] px-2.5 py-2 text-sm text-[var(--color-fg-on-dark-muted)] hover:bg-[var(--color-sidebar-hover)] hover:text-[var(--color-fg-on-dark)] transition-colors",
                    collapsed && "justify-center"
                  )}
                >
                  {item.icon}
                  {!collapsed && (
                    <>
                      <span className="flex-1 text-left">{item.label}</span>
                      {open ? (
                        <ChevronDown className="h-3.5 w-3.5 opacity-60" />
                      ) : (
                        <ChevronRight className="h-3.5 w-3.5 opacity-60" />
                      )}
                    </>
                  )}
                </button>
                {open && !collapsed && (
                  <div className="ml-3 mt-0.5 space-y-0.5 border-l border-white/10 pl-2">
                    {item.children.map((child) => (
                      <button
                        key={child.href}
                        type="button"
                        onClick={() => handleNav(child.href)}
                        className={cn(
                          "flex w-full items-center rounded-[var(--radius-sm)] px-2.5 py-1.5 text-[13px] transition-colors",
                          isActive(child.href)
                            ? "bg-[var(--color-sidebar-active)] text-white font-medium"
                            : "text-[var(--color-fg-on-dark-muted)] hover:bg-[var(--color-sidebar-hover)] hover:text-[var(--color-fg-on-dark)]"
                        )}
                      >
                        {child.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          return (
            <button
              key={item.label}
              type="button"
              onClick={() => item.href && handleNav(item.href)}
              className={cn(
                "flex w-full items-center gap-2.5 rounded-[var(--radius-md)] px-2.5 py-2 text-sm transition-colors",
                isActive(item.href)
                  ? "bg-[var(--color-sidebar-active)] text-white font-medium"
                  : "text-[var(--color-fg-on-dark-muted)] hover:bg-[var(--color-sidebar-hover)] hover:text-[var(--color-fg-on-dark)]",
                collapsed && "justify-center"
              )}
            >
              {item.icon}
              {!collapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      {!collapsed && (
        <div className="border-t border-white/10 px-4 py-3">
          <p className="text-[10px] text-[var(--color-fg-on-dark-muted)]">
            v1.0 · Módulo de Penalidades
          </p>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "hidden lg:flex flex-col bg-[var(--color-sidebar)] text-[var(--color-fg-on-dark)] transition-all duration-200 shrink-0",
          collapsed ? "w-[60px]" : "w-[240px]"
        )}
      >
        {content}
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={onMobileClose}
          />
          <aside className="absolute left-0 top-0 h-full w-[260px] bg-[var(--color-sidebar)] shadow-xl">
            <div className="absolute right-2 top-3">
              <button
                type="button"
                onClick={onMobileClose}
                className="rounded p-1.5 text-[var(--color-fg-on-dark-muted)] hover:bg-[var(--color-sidebar-hover)]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {content}
          </aside>
        </div>
      )}
    </>
  );
}

export function MobileMenuButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="lg:hidden rounded-[var(--radius-md)] p-2 text-[var(--color-fg-muted)] hover:bg-[var(--color-bg-subtle)]"
      aria-label="Abrir menú"
    >
      <Menu className="h-5 w-5" />
    </button>
  );
}
