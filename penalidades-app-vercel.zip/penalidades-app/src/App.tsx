import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { DashboardPage } from "@/pages/DashboardPage";
import { FailuresListPage } from "@/pages/FailuresListPage";
import { NewFailurePage } from "@/pages/NewFailurePage";
import { PaymentTrackingPage } from "@/pages/PaymentTrackingPage";

const TITLES: Record<string, string> = {
  "/": "Dashboard",
  "/penalidades": "Listado de Faltas",
  "/penalidades/nueva": "Registrar Falta",
  "/penalidades/historial": "Historial de Faltas",
  "/notas-debito": "Listado de ND",
  "/notas-debito/nueva": "Registrar ND",
  "/notas-debito/seguimiento": "Seguimiento de Pagos",
  "/catalogos/proveedores": "Proveedores",
  "/catalogos/tipos-servicio": "Tipos de Servicio",
  "/catalogos/categorias": "Categorías de Falta",
  "/catalogos/ubicaciones": "Ubicaciones",
  "/catalogos/tarifas": "Tarifas",
  "/catalogos/geografia": "Geografía",
  "/alertas/proximas": "Alertas próximas",
  "/alertas/vencidas": "Alertas vencidas",
  "/alertas/historial": "Historial de alertas",
  "/reportes": "Reportes",
  "/admin/usuarios": "Usuarios",
  "/admin/roles": "Roles",
  "/admin/permisos": "Permisos",
  "/admin/auditoria": "Auditoría",
};

function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="rounded-[var(--radius-xl)] border border-dashed border-[var(--color-border-strong)] bg-[var(--color-bg-elevated)] px-12 py-10">
        <h2 className="text-lg font-semibold text-[var(--color-fg)]">{title}</h2>
        <p className="mt-2 max-w-sm text-sm text-[var(--color-fg-muted)]">
          Módulo preparado. Se implementará con persistencia y reglas de negocio en la
          siguiente fase.
        </p>
      </div>
    </div>
  );
}

export default function App() {
  const [path, setPath] = useState("/");

  const title = TITLES[path] ?? "Penalidades";

  let content: React.ReactNode;
  switch (path) {
    case "/":
      content = <DashboardPage />;
      break;
    case "/penalidades":
      content = <FailuresListPage onNew={() => setPath("/penalidades/nueva")} />;
      break;
    case "/penalidades/nueva":
      content = <NewFailurePage onBack={() => setPath("/penalidades")} />;
      break;
    case "/notas-debito/seguimiento":
      content = <PaymentTrackingPage />;
      break;
    default:
      content = <PlaceholderPage title={title} />;
  }

  return (
    <AppShell title={title} currentPath={path} onNavigate={setPath}>
      {content}
    </AppShell>
  );
}
