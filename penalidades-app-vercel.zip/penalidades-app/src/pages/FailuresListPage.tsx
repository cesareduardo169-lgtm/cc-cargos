import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/DataTable";
import { Badge } from "@/components/ui/badge";

type FailureRow = {
  id: string;
  failure_number: string;
  registered_at: string;
  provider_name: string;
  category_name: string;
  location_name: string;
  penalty_cost: number;
  has_debit_note: boolean;
};

const DEMO_FAILURES: FailureRow[] = [
  {
    id: "1",
    failure_number: "FLT-2026-0001",
    registered_at: "2026-09-02 09:14",
    provider_name: "G4S",
    category_name: "Falta Grave",
    location_name: "Red de Agencia",
    penalty_cost: 367,
    has_debit_note: true,
  },
  {
    id: "2",
    failure_number: "FLT-2026-0002",
    registered_at: "2026-09-05 11:30",
    provider_name: "PROSEGURIDAD",
    category_name: "Faltas en el Servicio",
    location_name: "Sede Principal",
    penalty_cost: 5245,
    has_debit_note: true,
  },
  {
    id: "3",
    failure_number: "FLT-2026-0003",
    registered_at: "2026-09-08 16:02",
    provider_name: "COMETAL",
    category_name: "Personal no Idóneo",
    location_name: "Sede Principal",
    penalty_cost: 400,
    has_debit_note: false,
  },
  {
    id: "4",
    failure_number: "FLT-2026-0004",
    registered_at: "2026-09-10 08:45",
    provider_name: "SECURITY SALES",
    category_name: "Tardanzas",
    location_name: "Red de Agencia",
    penalty_cost: 5245,
    has_debit_note: true,
  },
  {
    id: "5",
    failure_number: "FLT-2026-0005",
    registered_at: "2026-09-12 14:20",
    provider_name: "G4S",
    category_name: "Faltas Regulatorias",
    location_name: "Red de Agencia",
    penalty_cost: 5245,
    has_debit_note: false,
  },
  {
    id: "6",
    failure_number: "FLT-2026-0006",
    registered_at: "2026-09-15 10:05",
    provider_name: "PROSEGURIDAD",
    category_name: "Falta Grave",
    location_name: "Sede Principal",
    penalty_cost: 367,
    has_debit_note: false,
  },
];

const columns: Column<FailureRow>[] = [
  {
    key: "failure_number",
    header: "Nº Falta",
    render: (r) => (
      <span className="font-medium tabular-nums text-[var(--color-primary)]">
        {r.failure_number}
      </span>
    ),
  },
  {
    key: "registered_at",
    header: "Fecha registro",
    render: (r) => (
      <span className="tabular-nums text-[var(--color-fg-muted)]">{r.registered_at}</span>
    ),
  },
  { key: "provider_name", header: "Proveedor" },
  { key: "category_name", header: "Categoría" },
  { key: "location_name", header: "Ubicación" },
  {
    key: "penalty_cost",
    header: "Costo",
    render: (r) => (
      <span className="font-medium tabular-nums">
        S/ {r.penalty_cost.toLocaleString("es-PE", { minimumFractionDigits: 2 })}
      </span>
    ),
  },
  {
    key: "has_debit_note",
    header: "ND",
    render: (r) =>
      r.has_debit_note ? (
        <Badge variant="success">Generada</Badge>
      ) : (
        <Badge variant="outline">Pendiente</Badge>
      ),
  },
];

interface FailuresListPageProps {
  onNew?: () => void;
}

export function FailuresListPage({ onNew }: FailuresListPageProps) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Listado de Faltas</h2>
          <p className="text-sm text-[var(--color-fg-muted)]">
            Registro de incidencias operativas
          </p>
        </div>
        <Button onClick={onNew}>
          <Plus className="h-4 w-4" />
          Nueva Falta
        </Button>
      </div>

      <DataTable
        columns={columns}
        data={DEMO_FAILURES}
        searchPlaceholder="Buscar por número, proveedor, categoría..."
      />
    </div>
  );
}
