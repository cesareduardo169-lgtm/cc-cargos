import { useState } from "react";
import { ArrowLeft, Calculator, AlertTriangle, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Textarea, Label } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const PROVIDERS = ["G4S", "PROSEGURIDAD", "COMETAL", "SECURITY SALES"];
const SERVICE_TYPES = ["Servicio Fijo", "Servicio Especial", "Proyecto de Llaves"];
const CATEGORIES = [
  "Falta Grave",
  "Faltas en el Servicio",
  "Faltas Regulatorias",
  "Personal no Idóneo",
  "Tardanzas",
];
const LOCATIONS = ["Red de Agencia", "Sede Principal"];
const DEPARTMENTS = ["Lima", "Arequipa", "La Libertad"];
const PROVINCES: Record<string, string[]> = {
  Lima: ["Lima", "Huaral"],
  Arequipa: ["Arequipa"],
  "La Libertad": ["Trujillo"],
};
const DISTRICTS: Record<string, string[]> = {
  Lima: ["Lima", "Miraflores", "San Isidro"],
  Huaral: ["Huaral"],
  Arequipa: ["Arequipa"],
  Trujillo: ["Trujillo"],
};

/** Motor de tarifas (demo — espejo de la lógica real) */
function calcCost(category: string, location: string): number | null {
  if (!category || !location) return null;
  if (category === "Falta Grave") return 367;
  if (category === "Personal no Idóneo" && location === "Sede Principal") return 400;
  if (
    ["Faltas en el Servicio", "Faltas Regulatorias", "Tardanzas", "Personal no Idóneo"].includes(
      category
    )
  )
    return 5245;
  return null;
}

interface NewFailurePageProps {
  onBack?: () => void;
}

export function NewFailurePage({ onBack }: NewFailurePageProps) {
  const [provider, setProvider] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [department, setDepartment] = useState("");
  const [province, setProvince] = useState("");
  const [district, setDistrict] = useState("");
  const [saved, setSaved] = useState(false);

  const cost = calcCost(category, location);
  const thresholdAlert = false; // demo

  const selectClass =
    "flex h-9 w-full rounded-[var(--radius-md)] border border-[var(--color-border-strong)] bg-[var(--color-bg-elevated)] px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)]";

  if (saved) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-success-bg)]">
          <Save className="h-6 w-6 text-[var(--color-success)]" />
        </div>
        <h2 className="text-xl font-semibold">Falta registrada correctamente</h2>
        <p className="text-[var(--color-fg-muted)]">
          Se generó el correlativo{" "}
          <span className="font-semibold text-[var(--color-primary)] tabular-nums">
            FLT-2026-0007
          </span>
        </p>
        <div className="flex justify-center gap-2 pt-2">
          <Button variant="outline" onClick={onBack}>
            Volver al listado
          </Button>
          <Button onClick={() => setSaved(false)}>Registrar otra</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-lg font-semibold">Nueva Falta</h2>
          <p className="text-sm text-[var(--color-fg-muted)]">
            Registro de incidencia operativa · Número se genera automáticamente
          </p>
        </div>
      </div>

      {/* Identificación */}
      <Card>
        <CardHeader>
          <CardTitle>Identificación</CardTitle>
          <CardDescription>
            Número correlativo: <Badge variant="outline">FLT-2026-XXXX</Badge> (automático)
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label required>Proveedor</Label>
            <select
              className={selectClass}
              value={provider}
              onChange={(e) => setProvider(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {PROVIDERS.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label required>Tipo de Servicio</Label>
            <select
              className={selectClass}
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {SERVICE_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label required>Categoría de Falta</Label>
            <select
              className={selectClass}
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label required>Ubicación</Label>
            <select
              className={selectClass}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            >
              <option value="">Seleccionar...</option>
              {LOCATIONS.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Ubicación geográfica */}
      <Card>
        <CardHeader>
          <CardTitle>Ubicación operativa</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Agencia</Label>
            <Input placeholder="Nombre o código de agencia" />
          </div>
          <div className="space-y-1.5">
            <Label>Cod_Topaz</Label>
            <Input placeholder="Código en sistema Core Topaz" />
          </div>
          <div className="space-y-1.5">
            <Label>Departamento</Label>
            <select
              className={selectClass}
              value={department}
              onChange={(e) => {
                setDepartment(e.target.value);
                setProvince("");
                setDistrict("");
              }}
            >
              <option value="">Seleccionar...</option>
              {DEPARTMENTS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Provincia</Label>
            <select
              className={selectClass}
              value={province}
              onChange={(e) => {
                setProvince(e.target.value);
                setDistrict("");
              }}
              disabled={!department}
            >
              <option value="">Seleccionar...</option>
              {(PROVINCES[department] ?? []).map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Distrito</Label>
            <select
              className={selectClass}
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              disabled={!province}
            >
              <option value="">Seleccionar...</option>
              {(DISTRICTS[province] ?? []).map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Detalle */}
      <Card>
        <CardHeader>
          <CardTitle>Detalle del incumplimiento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label required>Observación</Label>
            <Textarea placeholder="Describa el incumplimiento detectado..." rows={3} />
          </div>
          <div className="space-y-1.5">
            <Label>Descargo del proveedor</Label>
            <Textarea placeholder="Justificación o descargo (opcional)..." rows={2} />
          </div>
          <div className="space-y-1.5">
            <Label>Adjuntar descargo</Label>
            <Input type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" />
            <p className="text-[11px] text-[var(--color-fg-subtle)]">
              PDF, JPG, PNG, DOC/DOCX · máx. 10 MB
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Costo autocompletado */}
      <Card className="border-[var(--color-primary)]/30 bg-[var(--color-primary-muted)]/30">
        <CardContent className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-primary)] text-white">
              <Calculator className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium">Costo de Penalidad</p>
              <p className="text-xs text-[var(--color-fg-muted)]">
                Calculado desde el catálogo de tarifas
              </p>
            </div>
          </div>
          <div className="text-right">
            {cost !== null ? (
              <p className="text-2xl font-semibold tabular-nums text-[var(--color-primary)]">
                S/ {cost.toLocaleString("es-PE", { minimumFractionDigits: 2 })}
              </p>
            ) : (
              <p className="text-sm text-[var(--color-fg-muted)]">
                Seleccione categoría y ubicación
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {thresholdAlert && (
        <div className="flex items-start gap-3 rounded-[var(--radius-lg)] border border-[var(--color-warning)] bg-[var(--color-warning-bg)] p-4">
          <AlertTriangle className="h-5 w-5 shrink-0 text-[var(--color-warning)]" />
          <div>
            <p className="text-sm font-medium text-[var(--color-warning)]">
              Alerta contractual
            </p>
            <p className="text-xs text-[var(--color-fg-muted)]">
              El proveedor ha alcanzado el umbral de 13 servicios con faltas acumuladas. Se
              requiere revisión contractual. El costo de la penalidad no se incrementa.
            </p>
          </div>
        </div>
      )}

      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onBack}>
          Cancelar
        </Button>
        <Button
          onClick={() => setSaved(true)}
          disabled={!provider || !serviceType || !category || !location || cost === null}
        >
          <Save className="h-4 w-4" />
          Guardar Falta
        </Button>
      </div>
    </div>
  );
}
